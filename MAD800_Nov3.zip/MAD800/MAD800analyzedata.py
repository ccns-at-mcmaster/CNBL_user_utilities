import pandas as pd
import numpy as np
import MAD800opendata
from pandas.api.types import is_categorical_dtype
import matplotlib.pyplot as plt
import scipy.ndimage

def bindata(column, binning, df):
    """
    Bins a column of the DataFrame into specified intervals and assigns labels as midpoints.

    Parameters:
        column (str): Name of the column to bin.
        binning (tuple): Tuple of three values (start, end, steps) defining binning.
        df (pd.DataFrame): The DataFrame containing the column.

    Returns:
        str: The name of the column with binned data.

    Note:
        This function modifies the input DataFrame in place by adding new columns.

    """
    # Validate the binning parameter
    if binning is not None and (not isinstance(binning, tuple) or len(binning) != 3):
        raise ValueError(f"Binning parameter '{binning}' is not valid; must be a tuple of three numbers (start, end, steps).")
    
    # If no binning is specified, return the original column name
    if binning is None:
        binname = column
    else:
        # Define bin edges and labels as midpoints
        binname = column + '_bin'
        bins = np.linspace(binning[0], binning[1], binning[2] + 1)
        labels = (bins[:-1] + bins[1:]) / 2
        # Use pd.cut to bin the data
        df[binname] = pd.cut(df[column], bins=bins, labels=labels, right=False)
    return binname

def getmidvalues(df, *columns):
    """
    Adds a new column with midpoints for categorical data or retains the original values.

    Parameters:
        df (pd.DataFrame): The DataFrame containing the columns.
        *columns (str): Column names for which midpoints are to be calculated or assigned.
    
    Note:
        This function modifies the input DataFrame in place by adding new columns.
    """
    for column in columns:
        # Check if the column is categorical
        if is_categorical_dtype(df[column]):
            # Convert category labels (midpoints) to float
            df[column + '_mid'] = df[column].astype(float)
        else:
            # Retain original values for non-categorical columns
            df[column + '_mid'] = df[column]



def convertto1Ddata(Xcol, Ycol, df, *constraints, Moncol=None, binning=None, filename='all'):
    """
    Processes a DataFrame to compute aggregated 1D data, with optional binning and constraints.

    Parameters:
        Xcol (str): Column name for x-values (independent variable).
        Ycol (str): Column name for y-values (dependent variable).
        df (pd.DataFrame): The input DataFrame.
        *constraints (tuples): Constraints as (column_name, value)/(column_name, list) (in case of integer parameters) 
            or (column_name, [x1,x2]) for non-integer parameter.
        Moncol (str, optional): Column used for normalization.
        binning (tuple, optional): Tuple defining binning parameters (x1, x2, steps).
        filename (str or list, optional): Filter rows based on index.

    Returns:
        pd.DataFrame: Aggregated data with midpoints and optional error values.
    """
    # Step 1: Filter rows based on filename
    if filename == 'all':
        df1 = df.copy()
    elif isinstance(filename, str):
        df1 = df[df.index == filename]
    else:
        df1 = df[df.index.isin(filename)]

    # Step 2: Apply constraints
    mask = pd.Series(True, index=df1.index)
    for constraint in constraints:
        columntitle = constraint[0]
        if columntitle not in df1.columns:
            raise ValueError(f"Column '{columntitle}' not found in the DataFrame.")

        # Apply integer-based or range-based filtering
        if columntitle in MAD800opendata.integerparams:
            condition = df1[columntitle] == constraint[1] if isinstance(constraint[1], int) else df1[columntitle].isin(constraint[1])
        else:
            condition = (df1[columntitle] > constraint[1][0]) & (df1[columntitle] < constraint[1][1])
        mask &= condition

    # Filter the DataFrame
    df2 = df1[mask].dropna(subset=[Xcol,Ycol]).copy()

    # Step 3: Handle binning
    binname = bindata(Xcol, binning, df2)

    # Step 4: Aggregation
    if Moncol is None:
        # Compute mean without monitor column
        dftemp = df2.groupby(binname).agg({Ycol: 'mean'}).reset_index()
        dftemp = dftemp.rename(columns={Ycol: Ycol + '_binned'})
        dftemp[Ycol + '_binned_error'] = np.nan
        getmidvalues(dftemp, binname)
        return dftemp[[binname + '_mid', Ycol + '_binned', Ycol + '_binned_error']]
    else:
        # Compute normalized values and uncertainty
        dftemp = (
            df2.groupby(binname)
            .agg({Ycol: 'sum', Moncol: 'sum'})
            .assign(
                Y=lambda df: np.where(df[Moncol] != 0, df[Ycol] / df[Moncol], np.nan),
                dY=lambda df: np.where(df[Moncol] != 0, np.sqrt(df[Ycol].astype(float)) / df[Moncol], np.nan)
            )
            .reset_index()
        )
        dftemp = dftemp.rename(columns={'Y': Ycol + '_binned', 'dY': Ycol + '_binned_error'})
        getmidvalues(dftemp, binname)
        return dftemp[[binname + '_mid', Ycol + '_binned', Ycol + '_binned_error']]


def convertto2Ddata(Xcol, Ycol, Zcol, df, *constraints, Moncol=None, binx=None, biny=None, filename='all'):
    """
    Processes a DataFrame to compute aggregated 2D data, with optional binning and constraints.

    Parameters:
        Xcol (str): Column name for x-values.
        Ycol (str): Column name for y-values.
        Zcol (str): Column name for z-values (dependent variable).
        df (pd.DataFrame): The input DataFrame.
        *constraints (tuples): Constraints as (column_name, value)/(column_name, list) (in case of integer parameters) 
            or (column_name, [x1,x2]) for non-integer parameter.
        Moncol (str, optional): Column used for normalization.
        binx (tuple, optional): Tuple defining x-axis binning (x1, x2, steps).
        biny (tuple, optional): Tuple defining y-axis binning (y1, y2, steps).
        filename (str or list, optional): Filter rows based on index.

    Returns:
        pd.DataFrame: Aggregated 2D data with midpoints and optional error values.
    """
    # Step 1: Filter rows based on filename
    if filename == 'all':
        df1 = df.copy()
    elif isinstance(filename, str):
        df1 = df[df.index == filename]
    else:
        df1 = df[df.index.isin(filename)]

    # Step 2: Validate required columns
    required_columns = [Xcol, Ycol, Zcol] + [constraint[0] for constraint in constraints]
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"Column '{col}' not found in the DataFrame.")

    # Step 3: Apply constraints
    mask = pd.Series(True, index=df1.index)
    for constraint in constraints:
        columntitle = constraint[0]
        if columntitle in MAD800opendata.integerparams:
            condition = df1[columntitle] == constraint[1] if isinstance(constraint[1], int) else df1[columntitle].isin(constraint[1])
        else:
            condition = (df1[columntitle] > constraint[1][0]) & (df1[columntitle] < constraint[1][1])
        mask &= condition

    # Filter the DataFrame
    df2 = df1[mask].dropna(subset=[Xcol, Ycol,Zcol]).copy()

    # Step 4: Handle binning
    binnamex = bindata(Xcol, binx, df2)
    binnamey = bindata(Ycol, biny, df2)

    # Step 5: Aggregation
    if Moncol is None:
        # Compute mean for Zcol
        dftemp = df2.groupby([binnamex, binnamey]).agg({Zcol: 'mean'}).reset_index()
        dftemp = dftemp.rename(columns={Zcol: Zcol + '_binned'})
        dftemp[Zcol + '_binned_error'] = np.nan
        getmidvalues(dftemp, binnamex, binnamey)
        return dftemp[[binnamex + '_mid', binnamey + '_mid', Zcol + '_binned', Zcol + '_binned_error']]
    else:
        # Compute normalized values and uncertainty for Zcol
        dftemp = (
            df2.groupby([binnamex, binnamey])
            .agg({Zcol: 'sum', Moncol: 'sum'})
            .assign(
                Z=lambda df: np.where(df[Moncol] != 0, df[Zcol] / df[Moncol], np.nan),
                dZ=lambda df: np.where(df[Moncol] != 0, np.sqrt(df[Zcol].astype(float)) / df[Moncol], np.nan)
            )
            .reset_index()
        )
        dftemp = dftemp.rename(columns={'Z': Zcol + '_binned', 'dZ': Zcol + '_binned_error'})
        getmidvalues(dftemp, binnamex, binnamey)
        return dftemp[[binnamex + '_mid', binnamey + '_mid', Zcol + '_binned', Zcol + '_binned_error']]


def fill_small_nan_regions(grid, max_hole_size):
    """
    Fills NaN pixels with the intensity of the nearest valid pixel,
    provided their distance to that pixel is <= max_hole_size.

    Parameters:
        grid (np.ndarray): Input 2D array with NaN values.
        max_hole_size (float): Maximum distance in pixels from
            a NaN pixel to its nearest valid pixel.

    Returns:
        np.ndarray: Updated grid with nearby NaNs filled.
                    NaNs farther away remain unchanged.
    """

    filled_grid = grid.copy()
    nan_mask = np.isnan(grid)

    # Return unchanged if there is nothing to fill,
    # or no valid pixel is available
    if not nan_mask.any() or nan_mask.all():
        return filled_grid

    # Find distance and nearest valid pixel for every NaN
    distances, nearest_indices = scipy.ndimage.distance_transform_edt(
        nan_mask, return_indices=True
    )

    # Only fill NaNs sufficiently close to valid data
    fill_mask = nan_mask & (distances <= max_hole_size)

    # Copy the intensity of the nearest valid pixel
    filled_grid[fill_mask] = grid[
        tuple(nearest_indices[:, fill_mask])
    ]

    return filled_grid


def plot2D_with_hole_filling_and_weighted_smoothing(
    df, gridx=100, gridy=100, gaussian_sigma=None, max_hole_size=None, title=None, **kwargs
):
    """
    Generates a 2D colormap with binning, small-hole filling, and Gaussian smoothing.

    Parameters:
        df (pd.DataFrame): Input DataFrame with three columns [x, y, intensity].
        gridx (int): Number of grid points along the x-axis.
        gridy (int): Number of grid points along the y-axis.
        gaussian_sigma (float or tuple, optional): Standard deviations in number of bins for Gaussian smoothing.
        max_hole_size (int, optional): Maximum size of NaN regions (in number of bins) to fill.
        title (str, optional): Title for the plot. If None, defaults based on parameters.
        **kwargs: Additional keyword arguments passed to plt.pcolormesh.

    Returns:
        None: Displays the plot.
    """

    # Extract the column names for x, y, and intensity from the DataFrame
    x, y, intensity = df.columns[0], df.columns[1], df.columns[2]

    # Remove rows where x, y, or intensity are NaN to avoid issues in binning
    df = df.dropna(subset=[x, y, intensity]).copy()

    # Define bin edges along x and y axes
    x_edges = np.linspace(df[x].min(), df[x].max(), gridx + 1)  # Divides x-axis into equal gridx bins
    y_edges = np.linspace(df[y].min(), df[y].max(), gridy + 1)  # Divides y-axis into equal gridy bins

    # Assign each data point to a bin index using pd.cut()
    df['x_bin'] = pd.cut(df[x], bins=x_edges, labels=False, include_lowest=True)
    df['y_bin'] = pd.cut(df[y], bins=y_edges, labels=False, include_lowest=True)

    # Group by (y_bin, x_bin) and compute mean intensity for each bin
    binned = df.groupby(['y_bin', 'x_bin'])[intensity].mean().unstack(fill_value=np.nan)
    binned = binned.astype(float)  # ✅ Ensures dtype= float64

    # Ensure all x_bin and y_bin indices exist by reindexing
    all_x_bins = range(gridx)  # Full range of x_bin values
    all_y_bins = range(gridy)  # Full range of y_bin values
    binned = binned.reindex(index=all_y_bins, columns=all_x_bins, fill_value=np.nan)  # Fill missing bins with NaN

    # Apply hole-filling algorithm if a maximum hole size is specified
    if max_hole_size is not None:
        # filled_grid = fill_small_nan_regions(binned.values.copy(), max_hole_size, fill_value=0)
        filled_grid = fill_small_nan_regions(binned.values.copy(), max_hole_size)
    else:
        filled_grid = binned.values.copy()

    # Apply Gaussian smoothing if specified
    if gaussian_sigma is not None:
        if isinstance(gaussian_sigma, tuple):
            gaussian_sigma = (gaussian_sigma[1], gaussian_sigma[0])  # Swap order for correct (y, x) smoothing

        valid_mask = ~np.isnan(filled_grid)  # Mask to keep track of valid data points
        grid_for_smoothing = np.nan_to_num(filled_grid, nan=0)  # Replace NaNs with 0 for smoothing

        # Apply Gaussian filter separately to data and weights
        smoothed_data = scipy.ndimage.gaussian_filter(grid_for_smoothing, sigma=gaussian_sigma)
        smoothed_weights = scipy.ndimage.gaussian_filter(valid_mask.astype(float), sigma=gaussian_sigma)

        # Avoid divide-by-zero issues
        smoothed_weights[smoothed_weights == 0] = np.nan

        # Compute the final smoothed data using weighted averaging
        plot_data = smoothed_data / smoothed_weights

        # Restore original NaN regions to maintain data integrity
        plot_data[~valid_mask] = np.nan
    else:
        plot_data = filled_grid  # No smoothing applied

    # Compute bin centers for x and y to use in pcolormesh
    x_centers = (x_edges[:-1] + x_edges[1:]) / 2  # Midpoints of x bins
    y_centers = (y_edges[:-1] + y_edges[1:]) / 2  # Midpoints of y bins

    # ✅ Final safety check before plotting
    plot_data = np.array(plot_data, dtype=float)  # ✅ Force float dtype at the end


    # Create the 2D colormap plot using pcolormesh
    plt.pcolormesh(x_centers, y_centers, plot_data, **kwargs)
    plt.colorbar(label=intensity)  # Add colorbar with intensity label
    plt.xlabel(x)
    plt.ylabel(y)

    # Set the title
    if title:
        plt.title(title)

    # Show the plot
    plt.show()


