import numpy as np
import pandas as pd
import warnings
import os

# Dictionary to map shorthand parameter names to their names in the metadata
paramsdict = {
    'eta.rb': 'eta',
    'chi.rb': 'chi',
    'phi.rb': 'phi',
    'psi.rb': 'psi',
    'temp.rb0': 'TEMPERATURE 0',
    'temp.rb1': 'TEMPERATURE 1',
    'temp.rb2': 'TEMPERATURE 2',
    'temp.rb3': 'TEMPERATURE 3'
}

# List of column names that should contain integer values
integerparams = ['step', 'Run', 'channel']

def checkstring(str1):
    """
    Creates a function to check if a substring exists in a string.

    Parameters:
        str1 (str): The substring to search for.

    Returns:
        function: A function that takes a string and checks if `str1` is in it.
    """
    return lambda str2: str1 in str2


def getmetadata(filename):
    """
    Extract metadata and headings from a file.

    Parameters:
        filename (str): Path to the file.

    Returns:
        tuple: Contains lists of run numbers, separator indices, metadata blocks, 
               headings, data block start indices, and total lines in the file.
    """
    # Lists to store results
    separatoridxall = []    # Indices of lines starting with '***'
    runlistall = []         # List of run numbers
    metadatalst = []        # Metadata blocks
    headinglst = []         # List of headings
    runbeginningidxall = [] # Start indices of data blocks
    total_lines = 0         # Total number of lines in the file

    # Temporary variables for processing
    current_metadata = []   # Tracks current metadata block
    separator_found = False # Flag for metadata block detection
    heading_found = False   # Flag for heading line detection

    # Process the file line by line
    with open(filename, 'r') as data:
        for idx, line in enumerate(data):
            total_lines += 1

            if line.startswith('***'):  # Start of a metadata block
                separatoridxall.append(idx)
                if current_metadata:
                    metadatalst.append(current_metadata)
                current_metadata = []
                separator_found = True
                heading_found = False

            elif line == '\n':  # End of a metadata block
                runbeginningidxall.append(idx + 3)
                heading_found = True
                separator_found = False

            elif heading_found:  # Process heading after empty line
                headinglst.append(['step'] + list(filter(('|').__ne__, line.split())))
                heading_found = False

            elif separator_found:  # Add to current metadata block
                current_metadata.append(line)

            # Extract run number from the first line of metadata block
            if separator_found and len(current_metadata) == 1:
                try:
                    run_number = int(current_metadata[0].split(':')[1])
                    runlistall.append(run_number)
                except (IndexError, ValueError):
                    raise ValueError(f"Error parsing run number at line {idx}: {line.strip()}")

        if current_metadata:  # Append last metadata block if file ends abruptly
            metadatalst.append(current_metadata)

    return runlistall, separatoridxall, metadatalst, headinglst, runbeginningidxall, total_lines


def getparametervalue(parameter, metadata):
    """
    Extract parameter value from metadata.

    Parameters:
        parameter (str): The parameter name to extract.
        metadata (list): Metadata block.

    Returns:
        float: Extracted parameter value or NaN if not found.
    """
    parameter_name = paramsdict.get(parameter, parameter)  # Map to full name if applicable
    metadata_line = list(filter(checkstring(parameter_name), metadata))
    if metadata_line:
        return float(metadata_line[0].split(parameter_name)[-1].split()[1])  # Extract value
    return np.nan  # Return NaN if not found


def openfilenew(filename, parameters, Runs='all'):
    """
    Opens specific runs from a file and returns a DataFrame with selected parameters.

    Parameters:
        filename (str): Path to the file.
        parameters (list): List of parameters to extract.
        Runs (str, int, or list): Runs to process. Use 'all' to process all runs.

    Returns:
        pd.DataFrame: DataFrame containing the selected runs and parameters.
    """
    filename1 = os.path.split(filename)[1]
    cols_to_convert = list(set(parameters) & set(integerparams))  # Identify integer columns

    # Extract metadata
    runlistall, separatoridxall, metadatalst, headinglst, runbeginningidxall, totallines = getmetadata(filename)
    dflist = []

    # Determine which runs to process
    runlist = runlistall if Runs == 'all' else ([Runs] if isinstance(Runs, int) else Runs)

    # Process each run
    for run in runlist:
        idx = runlistall.index(run)
        heading = headinglst[idx]

        # Separate parameters based on availability in the heading
        params_inheading = list(set(parameters) & set(heading))
        params_notinheading = list(set(parameters) - set(params_inheading))

        # Handle empty runs
        if runbeginningidxall[idx] >= totallines or (run != runlistall[-1] and runbeginningidxall[idx] >= separatoridxall[idx + 1]):
            df = pd.DataFrame(index=[filename1], columns=parameters)
            df['Run'] = run
            warnings.warn(f"Run {run} in {filename1} is empty!")
        else:
            # Determine lines to read
            start_line = runbeginningidxall[idx]
            end_line = separatoridxall[idx + 1] if run != runlistall[-1] else totallines

            # Read the required portion of the file
            dftemp = pd.read_csv(
                filename, 
                skiprows=range(start_line),
                nrows=end_line - start_line if end_line else None,
                names=heading,
                header=None,
                sep='|'
            )

            df = dftemp[params_inheading]

            # Add parameters not in heading
            for param in params_notinheading:
                param_value = getparametervalue(param, metadatalst[idx])
                df.loc[:, param] = param_value
                if pd.isna(param_value):
                    warnings.warn(f"Run {run} in {filename1} does not contain {param}!")

            df['Run'] = run
            df.index = [filename1] * len(df)

        dflist.append(df)

    # Combine all runs into a single DataFrame
    df_final = pd.concat(dflist)

    # Process integer columns to restore NaN values
    nan_mask = df_final[cols_to_convert].isna()
    df_final[cols_to_convert] = df_final[cols_to_convert].fillna(0).astype(int)
    df_final[cols_to_convert] = df_final[cols_to_convert].where(~nan_mask, np.nan)

    return df_final  # Return the final DataFrame


                

def openfilelist(filelist, parameters, runlist):
    """
    Opens a list of .adata files and extracts specified parameters for given runs.

    Parameters:
        filelist (list): List of strings specifying the paths+filenames of the .adata files.
        parameters (list): List of data entries to be recorded.
        runlist (list): List specifying the runs to be opened for each file. Each element is either 
                        the string 'all' or a list of integers.

    Returns:
        pd.DataFrame: A pandas DataFrame logging all relevant data entries in the selected runs
                      for all .adata files in `filelist`.

    Notes:
        This function uses `openfilenew(filename, parameters, Runs='all')`.
    """
    dffinal = []  # List to collect DataFrames for each file

    # Process each file and its corresponding run list
    for i in range(len(filelist)):
        # Use openfilenew to process each file
        dftemp = openfilenew(filelist[i], parameters, Runs=runlist[i])
        dffinal.append(dftemp)  # Append the resulting DataFrame to the list

    # Concatenate all DataFrames without resetting the index
    return pd.concat(dffinal)  # Preserve the index (e.g., filenames)

                   


def openfilesfromcsv(csvfile):
    """
    Open a list of .adata files based on instructions in the CSV file.

    Parameters:
        csvfile (str): The name of the CSV file containing file and run information.

    Returns:
        DataFrame: A pandas DataFrame logging relevant data entries.

    Note:
        The CSV file must follow the format shown in the example (e.g., example800.csv).
    """
    df = pd.read_csv(csvfile, header=None)
    
    # Extract parameters
    params = df.iloc[0, 1].split(',')
    
    # Extract file list and run list
    filelist = df[0][1:].tolist()

    def process_run_entry(entry):
        if entry=='all':
            return 'all'
        else:
            ranges = entry.split(',')
            result = []
            for r in ranges:
                if '-' in r:
                    start, end = map(int, r.split('-'))
                    result.extend(range(start, end + 1))
                else:
                    result.append(int(r))
            return sorted(set(result))
    
    runlist = [process_run_entry(entry) for entry in df[1][1:].tolist()]

    
    # Placeholder for openfilelist logic
    df = openfilelist(filelist, params, runlist)
    return df



