import pandas as pd
import numpy as np
import MAD800opendata
from pandas.api.types import is_categorical_dtype
import matplotlib.pyplot as plt
import scipy.ndimage

def bindata(column, binning, df):
    """
    Bins a column of the DataFrame into specified intervals and assigns labels as midpoints.

    Parameters:
        column (str): Name of the column to bin.
        binning (tuple): Tuple of three values (start, end, steps) defining binning.
        df (pd.DataFrame): The DataFrame containing the column.

    Returns:
        str: The name of the column with binned data.

    Note:
        This function modifies the input DataFrame in place by adding new columns.

    """
    # Validate the binning parameter
    if binning is not None and (not isinstance(binning, tuple) or len(binning) != 3):
        raise ValueError(f"Binning parameter '{binning}' is not valid; must be a tuple of three numbers (start, end, steps).")
    
    # If no binning is specified, return the original column name
    if binning is None:
        binname = column
    else:
        # Define bin edges and labels as midpoints
        binname = column + '_bin'
        bins = np.linspace(binning[0], binning[1], binning[2] + 1)
        labels = (bins[:-1] + bins[1:]) / 2
        # Use pd.cut to bin the data
        df[binname] = pd.cut(df[column], bins=bins, labels=labels, right=False)
    return binname

def getmidvalues(df, *columns):
    """
    Adds a new column with midpoints for categorical data or retains the original values.

    Parameters:
        df (pd.DataFrame): The DataFrame containing the columns.
        *columns (str): Column names for which midpoints are to be calculated or assigned.
    
    Note:
        This function modifies the input DataFrame in place by adding new columns.
    """
    for column in columns:
        # Check if the column is categorical
        if is_categorical_dtype(df[column]):
            # Convert category labels (midpoints) to float
            df[column + '_mid'] = df[column].astype(float)
        else:
            # Retain original values for non-categorical columns
            df[column + '_mid'] = df[column]



def convertto1Ddata(Xcol, Ycol, df, *constraints, Moncol=None, binning=None, filename='all'):
    """
    Processes a DataFrame to compute aggregated 1D data, with optional binning and constraints.

    Parameters:
        Xcol (str): Column name for x-values (independent variable).
        Ycol (str): Column name for y-values (dependent variable).
        df (pd.DataFrame): The input DataFrame.
        *constraints (tuples): Constraints as (column_name, value)/(column_name, list) (in case of integer parameters) 
            or (column_name, [x1,x2]) for non-integer parameter.
        Moncol (str, optional): Column used for normalization.
        binning (tuple, optional): Tuple defining binning parameters (x1, x2, steps).
        filename (str or list, optional): Filter rows based on index.

    Returns:
        pd.DataFrame: Aggregated data with midpoints and optional error values.
    """
    # Step 1: Filter rows based on filename
    if filename == 'all':
        df1 = df.copy()
    elif isinstance(filename, str):
        df1 = df[df.index == filename]
    else:
        df1 = df[df.index.isin(filename)]

    # Step 2: Apply constraints
    mask = pd.Series(True, index=df1.index)
    for constraint in constraints:
        columntitle = constraint[0]
        if columntitle not in df1.columns:
            raise ValueError(f"Column '{columntitle}' not found in the DataFrame.")

        # Apply integer-based or range-based filtering
        if columntitle in MAD800opendata.integerparams:
            condition = df1[columntitle] == constraint[1] if isinstance(constraint[1], int) else df1[columntitle].isin(constraint[1])
        else:
            condition = (df1[columntitle] > constraint[1][0]) & (df1[columntitle] < constraint[1][1])
        mask &= condition

    # Filter the DataFrame
    df2 = df1[mask].dropna(subset=[Xcol,Ycol]).copy()

    # Step 3: Handle binning
    binname = bindata(Xcol, binning, df2)

    # Step 4: Aggregation
    if Moncol is None:
        # Compute mean without monitor column
        dftemp = df2.groupby(binname).agg({Ycol: 'mean'}).reset_index()
        dftemp = dftemp.rename(columns={Ycol: Ycol + '_binned'})
        dftemp[Ycol + '_binned_error'] = np.nan
        getmidvalues(dftemp, binname)
        return dftemp[[binname + '_mid', Ycol + '_binned', Ycol + '_binned_error']]
    else:
        # Compute normalized values and uncertainty
        dftemp = (
            df2.groupby(binname)
            .agg({Ycol: 'sum', Moncol: 'sum'})
            .assign(
                Y=lambda df: np.where(df[Moncol] != 0, df[Ycol] / df[Moncol], np.nan),
                dY=lambda df: np.where(df[Moncol] != 0, np.sqrt(df[Ycol]) / df[Moncol], np.nan)
            )
            .reset_index()
        )
        dftemp = dftemp.rename(columns={'Y': Ycol + '_binned', 'dY': Ycol + '_binned_error'})
        getmidvalues(dftemp, binname)
        return dftemp[[binname + '_mid', Ycol + '_binned', Ycol + '_binned_error']]


def convertto2Ddata(Xcol, Ycol, Zcol, df, *constraints, Moncol=None, binx=None, biny=None, filename='all'):
    """
    Processes a DataFrame to compute aggregated 2D data, with optional binning and constraints.

    Parameters:
        Xcol (str): Column name for x-values.
        Ycol (str): Column name for y-values.
        Zcol (str): Column name for z-values (dependent variable).
        df (pd.DataFrame): The input DataFrame.
        *constraints (tuples): Constraints as (column_name, value)/(column_name, list) (in case of integer parameters) 
            or (column_name, [x1,x2]) for non-integer parameter.
        Moncol (str, optional): Column used for normalization.
        binx (tuple, optional): Tuple defining x-axis binning (x1, x2, steps).
        biny (tuple, optional): Tuple defining y-axis binning (y1, y2, steps).
        filename (str or list, optional): Filter rows based on index.

    Returns:
        pd.DataFrame: Aggregated 2D data with midpoints and optional error values.
    """
    # Step 1: Filter rows based on filename
    if filename == 'all':
        df1 = df.copy()
    elif isinstance(filename, str):
        df1 = df[df.index == filename]
    else:
        df1 = df[df.index.isin(filename)]

    # Step 2: Validate required columns
    required_columns = [Xcol, Ycol, Zcol] + [constraint[0] for constraint in constraints]
    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"Column '{col}' not found in the DataFrame.")

    # Step 3: Apply constraints
    mask = pd.Series(True, index=df1.index)
    for constraint in constraints:
        columntitle = constraint[0]
        if columntitle in MAD800opendata.integerparams:
            condition = df1[columntitle] == constraint[1] if isinstance(constraint[1], int) else df1[columntitle].isin(constraint[1])
        else:
            condition = (df1[columntitle] > constraint[1][0]) & (df1[columntitle] < constraint[1][1])
        mask &= condition

    # Filter the DataFrame
    df2 = df1[mask].dropna(subset=[Xcol, Ycol,Zcol]).copy()

    # Step 4: Handle binning
    binnamex = bindata(Xcol, binx, df2)
    binnamey = bindata(Ycol, biny, df2)

    # Step 5: Aggregation
    if Moncol is None:
        # Compute mean for Zcol
        dftemp = df2.groupby([binnamex, binnamey]).agg({Zcol: 'mean'}).reset_index()
        dftemp = dftemp.rename(columns={Zcol: Zcol + '_binned'})
        dftemp[Zcol + '_binned_error'] = np.nan
        getmidvalues(dftemp, binnamex, binnamey)
        return dftemp[[binnamex + '_mid', binnamey + '_mid', Zcol + '_binned', Zcol + '_binned_error']]
    else:
        # Compute normalized values and uncertainty for Zcol
        dftemp = (
            df2.groupby([binnamex, binnamey])
            .agg({Zcol: 'sum', Moncol: 'sum'})
            .assign(
                Z=lambda df: np.where(df[Moncol] != 0, df[Zcol] / df[Moncol], np.nan),
                dZ=lambda df: np.where(df[Moncol] != 0, np.sqrt(df[Zcol]) / df[Moncol], np.nan)
            )
            .reset_index()
        )
        dftemp = dftemp.rename(columns={'Z': Zcol + '_binned', 'dZ': Zcol + '_binned_error'})
        getmidvalues(dftemp, binnamex, binnamey)
        return dftemp[[binnamex + '_mid', binnamey + '_mid', Zcol + '_binned', Zcol + '_binned_error']]


def fill_small_nan_regions(grid, max_hole_size, fill_value=0):
    """
    Fills only small NaN regions in a 2D grid, leaving large NaN regions untouched.

    Parameters:
        grid (np.ndarray): Input 2D array with NaN values.
        max_hole_size (int): Maximum size (in pixels) for a NaN region to be filled.
        fill_value (float): Value to replace small NaN regions.

    Returns:
        np.ndarray: Updated 2D array with small NaN regions filled.
    """
    # Create a binary mask: NaN regions are foreground (1), others are background (0)
    nan_mask = np.isnan(grid).astype(int)

    # Compute the Euclidean distance transform for the binary mask (distance from NaNs)
    distances = scipy.ndimage.distance_transform_edt(nan_mask)

    # Identify small NaN regions based on the distance transform
    small_nan_mask = (nan_mask == 1) & (distances <= max_hole_size)

    # Create a copy of the grid to modify
    filled_grid = grid.copy()

    # Fill the small NaN regions with the specified fill value
    filled_grid[small_nan_mask] = fill_value  # Replace small NaNs with 0

    return filled_grid

def plot2D_with_hole_filling_and_weighted_smoothing(
    df, gridx=100, gridy=100, gaussian_sigma=None, max_hole_size=None, **kwargs
):
    """
    Generates a 2D colormap with binning, small-hole filling, and Gaussian smoothing.

    Parameters:
        df (pd.DataFrame): Input DataFrame with three columns [x, y, intensity].
        gridx (int): Number of grid points along the x-axis.
        gridy (int): Number of grid points along the y-axis.
        gaussian_sigma (float or tuple, optional): Standard deviations in number of bins for Gaussian smoothing.
            If a tuple is provided, it should be in the format (sigma_x, sigma_y), where sigma_x is the standard
            deviation along the x-axis and sigma_y is the standard deviation along the y-axis. The tuple will be
            automatically flipped internally to (sigma_y, sigma_x) to match the axes in the data grid.
        max_hole_size (int, optional): Maximum size of NaN regions (in number of bins) to fill. If None, no filling is applied.
        fill_value (float): Value to replace small NaN regions.
        **kwargs: Additional keyword arguments passed to plt.pcolormesh.

    Returns:
        None: Displays the plot.
    """

    # Extract x, y, and intensity values from the DataFrame
    x, y, intensity = df.columns[0], df.columns[1], df.columns[2]
    df = df.dropna(subset=[x, y, intensity]).copy()

    # Define bin edges for binning the data
    x_edges = np.linspace(df[x].min(), df[x].max(), gridx + 1)
    y_edges = np.linspace(df[y].min(), df[y].max(), gridy + 1)

    # Bin data using pd.cut
    df['x_bin'] = pd.cut(df[x], bins=x_edges, labels=False, include_lowest=True)
    df['y_bin'] = pd.cut(df[y], bins=y_edges, labels=False, include_lowest=True)

    # Group by bins and calculate the mean intensity for each bin
    binned = df.groupby(['y_bin', 'x_bin'])[intensity].mean().unstack(fill_value=np.nan)

    # Reindex to ensure all bins are included
    all_x_bins = range(gridx)
    all_y_bins = range(gridy)
    binned = binned.reindex(index=all_y_bins, columns=all_x_bins, fill_value=np.nan)

    # Fill small NaN regions using distance-based filling
    if max_hole_size is not None:
        binned_values = binned.values.copy()
        filled_grid = fill_small_nan_regions(binned_values, max_hole_size, fill_value=0)  # Proper fill value
    else:
        filled_grid = binned.values.copy()

    # Apply Gaussian smoothing if specified
    if gaussian_sigma is not None:
        # Flip Gaussian sigma if it is a tuple to match the axes
        if isinstance(gaussian_sigma, tuple):
            gaussian_sigma = (gaussian_sigma[1], gaussian_sigma[0])

        # Create a binary mask for valid (non-NaN) data points from the filled grid
        valid_mask = ~np.isnan(filled_grid)

        # Replace all NaNs in the grid with 0 for smoothing
        grid_for_smoothing = np.nan_to_num(filled_grid, nan=0)

        # Apply Gaussian smoothing to the grid and the binary mask
        smoothed_data = scipy.ndimage.gaussian_filter(grid_for_smoothing, sigma=gaussian_sigma)
        smoothed_weights = scipy.ndimage.gaussian_filter(valid_mask.astype(float), sigma=gaussian_sigma)

        # Avoid divide-by-zero issues
        smoothed_weights[smoothed_weights == 0] = np.nan

        # Compute the weighted average (normalized smoothed data)
        plot_data = smoothed_data / smoothed_weights

        # Restore large NaN regions to their original NaN state
        plot_data[~valid_mask] = np.nan
    else:
        plot_data = filled_grid

    # Compute the bin centers for plotting
    x_centers = (x_edges[:-1] + x_edges[1:]) / 2
    y_centers = (y_edges[:-1] + y_edges[1:]) / 2

    # Plot the processed data
    plt.pcolormesh(x_centers, y_centers, plot_data, **kwargs)
    plt.colorbar(label=intensity)
    plt.xlabel(x)
    plt.ylabel(y)
    plt.title("Binned 2D Plot with Hole Filling and Smoothing" if gaussian_sigma else "Binned 2D Plot")
    plt.show()

