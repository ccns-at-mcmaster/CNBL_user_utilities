import tkinter as tk
import os
import numpy as np
from tkinter import filedialog, ttk, messagebox
import pandas as pd
import matplotlib.pyplot as plt
from MAD800opendata import openfilelist,integerparams
from MAD800analyzedata import convertto1Ddata, convertto2Ddata, plot2D_with_hole_filling_and_weighted_smoothing
from MAD800singlecrystal import UB,viewsc,channel_to_phi_map, MADparams
from crystal import Crystal
import random
import threading


class FullMAD800GUI(tk.Tk):
    
    def __init__(self):
        
        super().__init__()
        self.title("MAD800 Data Analysis")
        self.geometry("1000x800")
        
        self.files = []  # List of loaded files
        self.run_inputs = []  # List of Entry widgets for run numbers
        self.constraints_1d = []  # Constraints specific to 1D plots
        self.constraints_2d = []  # Constraints specific to 2D plots
        self.dataframe = None  # Placeholder for loaded data
        self.ub=None
        
        # Attributes to store selected filenames
        self.selected_files_1d = []  # Selected files for 1D plots
        self.selected_files_2d = []  # Selected files for 2D plots

        # Track the currently selected plot
        self.currentplot = None  

        # Different marker symbols for adding plots
        self.symbols = ['o', 's', '^', 'v', '*', 'D', 'x', '+']  
        self.colors = ["b", "g", "r", "c", "m", "y"]
        self.color_index = 0  # Track which symbol to use next
    
        self.init_ui()
    
    
    def init_ui(self):
        # Create Tabs
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(expand=True, fill="both")
        
        # Tabs
        self.load_tab = ttk.Frame(self.notebook)
        self.ub_tab = ttk.Frame(self.notebook)
        self.plot_tab = ttk.Frame(self.notebook)  # Combined Plot Tab
        
        self.notebook.add(self.load_tab, text="Load Data")
        self.notebook.add(self.ub_tab, text="UB Matrix")
        self.notebook.add(self.plot_tab, text="Plots")  # Single Plot Tab
        
        # Initialize each tab
        self.init_load_tab()
        self.init_ub_tab()
        self.init_plot_tab()

        # Acknowledgement
        credit_label = tk.Label(
            self,
            text="© 2025–2026 Bo Yuan. Developed with assistance from ChatGPT (OpenAI).",
            font=("Arial", 8),
            fg="gray"
        )
        credit_label.pack(side="bottom", pady=5)


    def init_plot_tab(self):
        """Initialize the combined Plot Tab with 1D and 2D sections."""
        # 1D Plot Frame
        self.plot1d_frame = ttk.LabelFrame(self.plot_tab, text="1D Plot", padding=10)
        self.plot1d_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

        # 2D Plot Frame
        self.plot2d_frame = ttk.LabelFrame(self.plot_tab, text="2D Plot", padding=10)
        self.plot2d_frame.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")

        # Make the frames expand
        self.plot_tab.columnconfigure(0, weight=1)
        self.plot_tab.columnconfigure(1, weight=1)
        self.plot_tab.rowconfigure(0, weight=1)
        
        # Initialize individual plot frames
        self.init_plot1d_frame()
        self.init_plot2d_frame()
    
    def init_load_tab(self):
        """Initialize the Load Data Tab."""
        ttk.Label(self.load_tab, text="Load Data Files", font=("Arial", 16)).pack(pady=10)

        # Add Files Button
        ttk.Button(self.load_tab, text="Add Files", command=self.add_files).pack(pady=5)

        # Frame to display added files and run number inputs
        self.files_frame = ttk.Frame(self.load_tab)
        self.files_frame.pack(fill="both", expand=True, padx=10, pady=5)

        # Parameters Input (Pre-filled with default values)
        self.param_entry = ttk.Entry(self.load_tab, width=50)
        self.param_entry.insert(0, "channel, eta.rb, chi.rb, psi.rb, cntr.mcnt, det.cnt")  # Pre-fill parameters
        self.param_entry.pack(pady=5)
        ttk.Label(self.load_tab, text="Parameters (comma-separated)").pack(pady=5)

        # Load Data Button
        ttk.Button(self.load_tab, text="Load Data", command=self.load_data).pack(pady=10)

    
    def init_ub_tab(self):
        ttk.Label(self.ub_tab, text="View Single Crystal Data", font=("Arial", 16)).pack(pady=10)  # Updated heading

        # Crystal Structure Inputs
        crystal_frame = ttk.LabelFrame(self.ub_tab, text="Crystal Structure", padding=10)
        crystal_frame.pack(fill="x", padx=10, pady=10)
        
        self.crystal_inputs = {}
        for i, param in enumerate(["a", "b", "c", "alpha", "beta", "gamma"]):
            ttk.Label(crystal_frame, text=f"{param}:").grid(row=i, column=0, sticky="e", padx=5, pady=5)
            entry = ttk.Entry(crystal_frame, width=20)
            entry.grid(row=i, column=1, padx=5, pady=5)
            self.crystal_inputs[param] = entry
        
        # UB Matrix Inputs
        ub_frame = ttk.LabelFrame(self.ub_tab, text="UB Matrix Calculation", padding=10)
        ub_frame.pack(fill="x", padx=10, pady=10)
        
        self.ub_inputs = {}
        for i, param in enumerate(["Q1", "angle1", "Q2", "angle2"]):
            ttk.Label(ub_frame, text=f"{param}:").grid(row=i, column=0, sticky="e", padx=5, pady=5)
            entry = ttk.Entry(ub_frame, width=50)
            entry.grid(row=i, column=1, padx=5, pady=5)
            self.ub_inputs[param] = entry
        
        # Buttons for Calculate UB Matrix and View Single Crystal Data
        button_frame = ttk.Frame(self.ub_tab)
        button_frame.pack(pady=10)

        ttk.Button(button_frame, text="Calculate UB Matrix", command=self.calculate_ub).grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="View Single Crystal Data", command=self.apply_UB_matrix).grid(row=0, column=1, padx=5)

    
    def init_plot1d_frame(self):
        """Initialize the 1D Plot Frame."""
        ttk.Label(self.plot1d_frame, text="1D Plot", font=("Arial", 16)).grid(row=0, column=0, columnspan=2, pady=10)

        # File selection
        ttk.Button(self.plot1d_frame, text="Select Data Files", command=lambda: self.select_files("1D")).grid(row=1, column=0, columnspan=2, pady=5)
        self.selected_files_label = ttk.Label(self.plot1d_frame, text="No files selected")
        self.selected_files_label.grid(row=2, column=0, columnspan=2, pady=5)

        # Parameter inputs
        ttk.Label(self.plot1d_frame, text="X").grid(row=3, column=0, sticky="e", padx=5, pady=5)
        self.x_entry = ttk.Entry(self.plot1d_frame, width=20)
        self.x_entry.grid(row=3, column=1, padx=5, pady=5)

        ttk.Label(self.plot1d_frame, text="Y").grid(row=4, column=0, sticky="e", padx=5, pady=5)
        self.y_entry = ttk.Entry(self.plot1d_frame, width=20)
        self.y_entry.grid(row=4, column=1, padx=5, pady=5)

        ttk.Label(self.plot1d_frame, text="Monitor (optional)").grid(row=5, column=0, sticky="e", padx=5, pady=5)
        self.monitor_entry = ttk.Entry(self.plot1d_frame, width=20)
        self.monitor_entry.grid(row=5, column=1, padx=5, pady=5)

        ttk.Label(self.plot1d_frame, text="Bin (optional)").grid(row=6, column=0, sticky="e", padx=5, pady=5)
        self.bin_entry = ttk.Entry(self.plot1d_frame, width=20)
        self.bin_entry.grid(row=6, column=1, padx=5, pady=5)

        # Add constraint button
        ttk.Button(self.plot1d_frame, text="Add Constraint", command=lambda: self.add_constraint("1D")).grid(row=7, column=0, columnspan=2, pady=5)

        # Frame to display 1D constraints
        ttk.Label(self.plot1d_frame, text="Constraints:").grid(row=8, column=0, sticky="w", padx=10, pady=5)
        self.constraints_frame_1d = ttk.Frame(self.plot1d_frame)
        self.constraints_frame_1d.grid(row=9, column=0, columnspan=2, sticky="ew", padx=10, pady=10)

        # Plot button
        ttk.Button(self.plot1d_frame, text="Plot", command=self.plot_1d).grid(row=10, column=0, columnspan=2, pady=10)
        # add to existing plot button
        ttk.Button(self.plot1d_frame, text="Add to Plot", command=self.add_to_existing_plot).grid(row=11, column=0, columnspan=2, pady=5)
        # Export to ascii/csv button
        ttk.Button(self.plot1d_frame, text="Export to CSV/ASCII", command=self.export_1d).grid(row=12, column=0, columnspan=2, pady=10)
       # Export powder pattern
        ttk.Button(self.plot1d_frame, text="Export powder pattern", command=self.export_powder).grid(row=13, column=0, columnspan=2, pady=10)

    def init_plot2d_frame(self):
        """Initialize the 2D Plot Frame."""
        ttk.Label(self.plot2d_frame, text="2D Plot", font=("Arial", 16)).grid(row=0, column=0, columnspan=2, pady=10)

        # File selection
        ttk.Button(self.plot2d_frame, text="Select Data Files", command=lambda: self.select_files("2D")).grid(row=1, column=0, columnspan=2, pady=5)
        self.selected_files_label_2d = ttk.Label(self.plot2d_frame, text="No files selected")
        self.selected_files_label_2d.grid(row=2, column=0, columnspan=2, pady=5)

        # Parameter inputs
        ttk.Label(self.plot2d_frame, text="X").grid(row=3, column=0, sticky="e", padx=5, pady=5)
        self.x2_entry = ttk.Entry(self.plot2d_frame, width=20)
        self.x2_entry.grid(row=3, column=1, padx=5, pady=5)

        ttk.Label(self.plot2d_frame, text="Y").grid(row=4, column=0, sticky="e", padx=5, pady=5)
        self.y2_entry = ttk.Entry(self.plot2d_frame, width=20)
        self.y2_entry.grid(row=4, column=1, padx=5, pady=5)

        ttk.Label(self.plot2d_frame, text="Z").grid(row=5, column=0, sticky="e", padx=5, pady=5)
        self.z_entry = ttk.Entry(self.plot2d_frame, width=20)
        self.z_entry.grid(row=5, column=1, padx=5, pady=5)

        ttk.Label(self.plot2d_frame, text="Monitor (optional)").grid(row=6, column=0, sticky="e", padx=5, pady=5)
        self.monitor2_entry = ttk.Entry(self.plot2d_frame, width=20)
        self.monitor2_entry.grid(row=6, column=1, padx=5, pady=5)

        ttk.Label(self.plot2d_frame, text="Binx (optional)").grid(row=7, column=0, sticky="e", padx=5, pady=5)
        self.binx_entry = ttk.Entry(self.plot2d_frame, width=20)
        self.binx_entry.grid(row=7, column=1, padx=5, pady=5)

        ttk.Label(self.plot2d_frame, text="Biny (optional)").grid(row=8, column=0, sticky="e", padx=5, pady=5)
        self.biny_entry = ttk.Entry(self.plot2d_frame, width=20)
        self.biny_entry.grid(row=8, column=1, padx=5, pady=5)

        ttk.Label(self.plot2d_frame, text="Smoothing (gaussian_sigma)").grid(row=9, column=0, sticky="e", padx=5, pady=5)
        self.smoothing_entry = ttk.Entry(self.plot2d_frame, width=20)
        self.smoothing_entry.grid(row=9, column=1, padx=5, pady=5)

        ttk.Label(self.plot2d_frame, text="Max Hole Size").grid(row=10, column=0, sticky="e", padx=5, pady=5)
        self.max_hole_entry = ttk.Entry(self.plot2d_frame, width=20)
        self.max_hole_entry.grid(row=10, column=1, padx=5, pady=5)

        # Add constraint button
        ttk.Button(self.plot2d_frame, text="Add Constraint", command=lambda: self.add_constraint("2D")).grid(row=11, column=0, columnspan=2, pady=5)

        # Frame to display 2D constraints
        ttk.Label(self.plot2d_frame, text="Constraints:").grid(row=12, column=0, sticky="w", padx=10, pady=5)
        self.constraints_frame_2d = ttk.Frame(self.plot2d_frame)
        self.constraints_frame_2d.grid(row=13, column=0, columnspan=2, sticky="ew", padx=10, pady=10)

        # Plot button
        ttk.Button(self.plot2d_frame, text="Plot", command=self.plot_2d).grid(row=14, column=0, columnspan=2, pady=10)

        # Export to ascii/csv button
        ttk.Button(self.plot2d_frame, text="Export to CSV/ASCII", command=self.export_2d).grid(row=15, column=0, columnspan=2, pady=10)

    
    
    def add_files(self):
        """Handle adding files and dynamically update the file list."""
        new_files = filedialog.askopenfilenames(title="Select Files")
        
        if new_files:
            # Normalize paths and filter out duplicates
            new_files = [os.path.normpath(file) for file in new_files if os.path.normpath(file) not in self.files]

            if new_files:
                for file in new_files:
                    self.files.append(file)
                    self.run_inputs.append("all")  # Default to "all"
                self.refresh_file_list()
            else:
                messagebox.showinfo("Info", "No new files were added. All selected files are already in the list.")


    def delete_file(self, index):
        """Remove a file from the list and update the UI."""
        del self.files[index]
        del self.run_inputs[index]
        self.refresh_file_list()


    def refresh_file_list(self):
        """Refresh the file list UI and display the current files and run numbers."""
        # Clear existing widgets in the files_frame
        for widget in self.files_frame.winfo_children():
            widget.destroy()
        
        # Rebuild the UI for each file
        for row, file in enumerate(self.files):
            # Display file path
            ttk.Label(self.files_frame, text=f"File {row + 1}: {file}").grid(row=row, column=0, sticky="w", padx=5, pady=5)
            
            # Entry widget for run number
            run_entry = ttk.Entry(self.files_frame, width=20)
            run_entry.grid(row=row, column=1, padx=5, pady=5)
            run_entry.insert(0, self.run_inputs[row])  # Populate with the current value
            
            # Update `self.run_inputs` dynamically when the entry is changed
            def update_run_input(event, index=row):
                self.run_inputs[index] = event.widget.get()
            
            run_entry.bind("<FocusOut>", lambda event, e=run_entry, idx=row: update_run_input(event, idx))
       
            # Delete button for the file
            delete_button = ttk.Button(self.files_frame, text="Delete", command=lambda idx=row: self.delete_file(idx))
            delete_button.grid(row=row, column=2, padx=5, pady=5)


    def add_constraint(self, target):
        """Add a constraint dynamically for 1D or 2D plots."""
        if self.dataframe is None:
            messagebox.showerror("Error", "No data loaded. Load data before adding constraints.")
            return
    
        constraint_window = tk.Toplevel(self)
        constraint_window.title(f"Add Constraint ({target})")
        
        ttk.Label(constraint_window, text="Select Parameter:").pack(pady=5)
        parameter_var = tk.StringVar()
        parameter_dropdown = ttk.Combobox(
            constraint_window, textvariable=parameter_var, values=list(self.dataframe.columns)
        )
        parameter_dropdown.pack(pady=5)
        
        ttk.Label(constraint_window, text="Enter Constraint:").pack(pady=5)
        constraint_entry = ttk.Entry(constraint_window, width=30)
        constraint_entry.pack(pady=5)
        
        def confirm_constraint():
            parameter = parameter_var.get()
            constraint = constraint_entry.get()
            
            if not parameter or not constraint:
                messagebox.showerror("Error", "Both parameter and constraint must be specified.")
                return
            
            # Add constraint to the appropriate target
            if target == "1D":
                self.constraints_1d.append((parameter, constraint))
                self.refresh_constraints_display("1D")
            elif target == "2D":
                self.constraints_2d.append((parameter, constraint))
                self.refresh_constraints_display("2D")
            
            constraint_window.destroy()
    
        ttk.Button(constraint_window, text="Add", command=confirm_constraint).pack(pady=10)



    def get_binning(self, x, bin_entry, df=None):
        """Calculate binning (x0, x1, steps) from specified DataFrame or self.dataframe."""
        try:
            if bin_entry.get():
                source_df = df if df is not None else self.dataframe
                return source_df[x].min(), source_df[x].max(), int(bin_entry.get())
        except ValueError:
            messagebox.showerror("Error", f"Invalid binning value: {bin_entry.get()}")
        return None


    def parse_constraints(self, constraints_list):
        """Parse constraints into a format accepted by convertto1Ddata."""
        parsed_constraints = []

        for param, values in constraints_list:
            try:
                if param in integerparams:
                    constraint_list = []

                    for item in values.split(','):
                        item = item.strip()

                        if '-' in item:
                            parts = item.split('-')

                            if len(parts) != 2:
                                raise ValueError(
                                    f"Invalid constraint for {param}. Use a single integer ('1'), "
                                    f"comma-separated integers ('1,2,3'), ranges ('1-5'), "
                                    f"or combinations ('1-5,8,10-12')."
                                )

                            start, end = map(int, parts)

                            if start > end:
                                raise ValueError(
                                    f"Invalid constraint for {param}. Use a single integer ('1'), "
                                    f"comma-separated integers ('1,2,3'), ranges ('1-5'), "
                                    f"or combinations ('1-5,8,10-12')."
                                )

                            constraint_list.extend(range(start, end + 1))
                        else:
                            constraint_list.append(int(item))

                    parsed_constraints.append((param, sorted(set(constraint_list))))
                else:
                    # Handle float constraints
                    if ',' in values:
                        # Comma-separated floats
                        parsed_constraints.append((param, [float(v.strip()) for v in values.split(',')]))
                    else:
                        # Single float is not valid
                        raise ValueError(f"Constraint for {param} must be comma-separated (e.g., '10.1,20.2').")
            except ValueError as ve:
                # Show error to the user and signal failure
                messagebox.showerror("Error", str(ve))
                return None

        return parsed_constraints

    def apply_constraints(self, df1, constraints):
        # Start with a mask that is True for all rows
        mask = pd.Series(True, index=df1.index)

        # Loop through each constraint (a tuple of column name and value(s) to filter by)
        for constraint in constraints:
            columntitle = constraint[0]

            # Check if the column exists in the DataFrame
            if columntitle not in df1.columns:
                raise ValueError(f"Column '{columntitle}' not found in the DataFrame.")

            # If the column is one of the predefined integer-type columns
            if columntitle in integerparams:
                # Apply equality check for a single integer
                # or .isin() for a list of integers
                condition = df1[columntitle] == constraint[1] if isinstance(constraint[1], int) else df1[columntitle].isin(constraint[1])
            else:
                # For float constraints, assume constraint[1] is a (min, max) range
                condition = (df1[columntitle] > constraint[1][0]) & (df1[columntitle] < constraint[1][1])

            # Combine this condition with the accumulated mask
            mask &= condition

        # Return the filtered DataFrame (copy ensures it’s detached from the original)
        return df1[mask].copy()


    def plot_1d(self):
        """Handle 1D plotting."""
        if self.dataframe is None:
            messagebox.showerror("Error", "No data loaded. Load data before plotting.")
            return

        x = self.x_entry.get().strip()
        y = self.y_entry.get().strip()
        monitor = self.monitor_entry.get().strip() if self.monitor_entry.get().strip() else None
        constraints = self.parse_constraints(self.constraints_1d)
        filename = self.selected_files_1d if self.selected_files_1d else 'all'
        df_reduced=self.apply_constraints(self.dataframe, constraints).copy(deep=True)
        binning = self.get_binning(x, self.bin_entry, df=df_reduced)

        try:
            data = convertto1Ddata(
                x, y, df_reduced, Moncol=monitor, binning=binning, filename=filename
            )

            label = str(self.constraints_1d) if self.constraints_1d else "No Constraint"
            plot_title = f"{y} vs {x}"  # ✅ Keep only subplot title

            fig = plt.figure()  # Create a new figure
            # Store the title for restoration in select_plot()
            fig._original_title = plot_title  # ✅ Store the correct title for later
            fig.canvas.mpl_connect('button_press_event', self.select_plot)  # ✅ Detect clicks on the figure

            plt.errorbar(
                data[data.columns[0]], data[data.columns[1]], yerr=np.nan_to_num(data[data.columns[2]], nan=0),
                fmt="k-|", capsize=2, label=label
            )
            plt.xlabel(x)
            plt.ylabel(y)
            plt.title(plot_title, fontsize=12, color='k')  # ✅ Use only subplot title (inside the plot)
            plt.legend()
            plt.show()

        except ValueError as ve:
            messagebox.showerror("Value Error", f"Invalid constraint or binning value: {ve}")
        except Exception as e:
            messagebox.showerror("Error", f"Error in 1D plotting: {e}")

    def export_1d(self):
        """Export 1D binned data (e.g., Q vs E with intensity) to CSV or ASCII format."""

        # ✅ Check if data has been loaded into the GUI; prevent export if empty
        if self.dataframe is None:
            messagebox.showerror("Error", "No data loaded. Load data before exporting.")
            return

        # ✅ Prompt user to choose a file path and format for saving the export
        file_path = filedialog.asksaveasfilename(
            defaultextension=".dat",  # Default extension
            filetypes=[
                ("ASCII text files", "*.dat"),
                ("CSV files", "*.csv"),
                ("All files", "*.*")
            ]
        )

        # ❌ Exit silently if user cancels the save dialog
        if not file_path:
            return

        # ✅ Try to generate the 1D binned data using user selections
        try:
            # ✅ Read axis choices from GUI entries
            x = self.x_entry.get().strip()
            y = self.y_entry.get().strip()

            # ✅ Read monitor column if provided (optional normalization)
            monitor = self.monitor_entry.get().strip() if self.monitor_entry.get().strip() else None

            # ✅ Parse additional user-defined constraints (e.g., filters)
            constraints = self.parse_constraints(self.constraints_1d)

            # ✅ Determine which files to include in the export
            filename = self.selected_files_1d if self.selected_files_1d else 'all'

            # Apply constraints before generating binned 1D data
            df_reduced=self.apply_constraints(self.dataframe, constraints).copy(deep=True)

            # ✅ Parse binning input (min, max, num_bins) for the X axis
            binning = self.get_binning(x, self.bin_entry, df=df_reduced)

            # ✅ Generate the actual 1D data (as a Pandas DataFrame)
            data = convertto1Ddata(
                x, y, df_reduced,
                Moncol=monitor, binning=binning, filename=filename
            )

        except Exception as e:
            # ❌ Show error message if axis names, binning, or constraints are invalid
            messagebox.showerror("Export Failed", f"Failed to generate 1D data:\n{e}")
            return

        # ✅ Try exporting the DataFrame to a text file (CSV or ASCII)
        try:
            if file_path.endswith(".csv"):
                # ✅ Export using comma separation
                data.to_csv(file_path, index=False, float_format="%.8f", na_rep="NaN")
            else:
                # ✅ Export using tab separation (ASCII-style)
                data.to_csv(file_path, sep='\t', index=False, float_format="%.8f", na_rep="NaN")

            # ✅ Notify user that export was successful
            messagebox.showinfo("Export Successful", f"Data exported to:\n{file_path}")

        except Exception as e:
            # ❌ Show error if file write fails (e.g., permission denied, disk error)
            messagebox.showerror("Export Failed", f"Failed to export file:\n{e}")


    def export_powder(self):
        """Export 1D binned powder data (i.e. xcol must be phi.rb, ycol must be intensity) to .xy/.dat file for gsas and fullprof."""

        # ✅ Check if data has been loaded into the GUI; prevent export if empty
        if self.dataframe is None:
            messagebox.showerror("Error", "No data loaded. Load data before exporting.")
            return

        # ✅ Prompt user to choose a file path and format for saving the export
        # .xy file consists of 2 columns: (2theta, intensity), with unevenly spaced 2theta
        # .dat file starts with (start 2theta) (step) (end 2theta) followed by (extrapolated) intensities at evenly spaced 2theta
        file_path = filedialog.asksaveasfilename(
            defaultextension=".xy",  # Default extension
            filetypes=[
                ("xy files", "*.xy"),
                ("dat files","*.dat")
            ]
        )

        def generate_xy_files(filename: str, df: pd.DataFrame):
            """
            Write a .xy file for GSAS(-II) from a DataFrame with two columns:
            2theta and intensity. 2theta is not evenly spaced
            
            Parameters:
                filename (str): Output file path ending with .xy
                df (pd.DataFrame): DataFrame with 2θ in column 0, intensity in column 1
            """
            if not filename.endswith(".xy"):
                raise ValueError("Output file must end with .xy")
            
            with open(filename, 'w') as f:
                f.write("# 2theta  intensity\n")
                for angle, inten in zip(df.iloc[:, 0], df.iloc[:, 1]):
                    f.write(f"{angle:.6f} {inten:.6f}\n")


        def generate_dat_files(dat_path: str, df: pd.DataFrame):
            """
            Generate .dat files for FullProf from a 2-column DataFrame. 
            Future improvement includes generating a .pcr file alongside .dat file
            
            Parameters:
                dat_path (str): Path to output .dat file (must end with '.dat').
                df (pd.DataFrame): DataFrame with 2θ in first column and intensity in second.
            """
            if not dat_path.endswith(".dat"):
                raise ValueError("dat_path must end with '.dat'")
            
            # Extract angle and intensity
            angle = df.iloc[:, 0].values
            intensity = df.iloc[:, 1].values

            # Generate uniform 2θ grid
            npts = len(angle)
            angle_uniform = np.linspace(angle.min(), angle.max(), npts)

            # Correct, consistent range
            start = angle_uniform[0]
            step = (angle_uniform[-1] - angle_uniform[0]) / (npts - 1)
            end = start + step * (npts - 1)

            intensity_uniform = np.interp(angle_uniform, angle, intensity)

            # Write .dat file
            with open(dat_path, "w") as f:
                f.write(f"{start:.6f} {step:.6f} {end:.6f}\n")
                for i in intensity_uniform:
                    f.write(f"{i:.6f}\n")


        # ❌ Exit silently if user cancels the save dialog
        if not file_path:
            return

        # ✅ Try to generate the 1D binned data using user selections
        try:
            # ✅ Read axis choices from GUI entries
            x = self.x_entry.get().strip()
            y = self.y_entry.get().strip()

            # Check the data loaded is a powder pattern
            if x and y and (x != 'phi.rb' or y not in ['det.cnt', 'I_norm']):
                messagebox.showerror("Export Failed", "Use the 'Export to CSV/ASCII' function for 1D data other than powder pattern.")
                return

            # ✅ Read monitor column if provided (optional normalization)
            monitor = self.monitor_entry.get().strip() if self.monitor_entry.get().strip() else None

            # ✅ Parse additional user-defined constraints (e.g., filters)
            constraints = self.parse_constraints(self.constraints_1d)

            # ✅ Determine which files to include in the export
            filename = self.selected_files_1d if self.selected_files_1d else 'all'

            # Apply constraints before generating binned 1D data
            df_reduced=self.apply_constraints(self.dataframe, constraints).copy(deep=True)

            # ✅ Parse binning input (min, max, num_bins) for the X axis
            binning = self.get_binning(x, self.bin_entry, df=df_reduced)

            # ✅ Generate the actual 1D data (as a Pandas DataFrame)
            data = convertto1Ddata(
                x, y, df_reduced,
                Moncol=monitor, binning=binning, filename=filename
            )

            # Keeping only the first two columns
            data_powder=data.iloc[:,:2].copy()

            if monitor:

                # If monitor exists, I=N/M, and dI= sqrt(N)/M, M is shared across all channels
                # the most reasonable intensity exported for refinement is then the actual integrated counts= (I/dI)^2
            
                data_powder[data_powder.columns[1]] = (data[data.columns[1]]/data[data.columns[2]])**2

            # Convert phi to positive
            data_powder[data_powder.columns[0]] *= -1
            
            # Drop invalid values: NaN, inf, -inf
            data_powder = data_powder.replace([np.inf, -np.inf], np.nan).dropna()

            # Sort the data
            data_powder = data_powder.sort_values(by=data_powder.columns[0]).reset_index(drop=True)

        except Exception as e:
            # ❌ Show error message if axis names, binning, or constraints are invalid
            messagebox.showerror("Export Failed", f"Failed to generate 1D data:\n{e}")
            return

        # ✅ Try exporting the DataFrame to an xy or dat file
        try:
            if file_path.endswith(".xy"):
                # Exporting xy file
                generate_xy_files(file_path,data_powder)

            elif file_path.endswith(".dat"):
                # Exporting .dat file
                generate_dat_files(file_path,data_powder)

            messagebox.showinfo("Export Successful", f"Powder pattern exported to:\n{file_path}")

        except Exception as e:
            # ❌ Show error if file write fails (e.g., permission denied, disk error)
            messagebox.showerror("Export Failed", f"Failed to export powder pattern:\n{e}")

    def select_plot(self, event):
        """Tracks the selected Matplotlib figure when clicked and updates its title."""
        if event.inaxes:  # ✅ Ensure click happened inside a figure
            new_selection = event.canvas.figure

            # Restore the old figure's title before switching
            if self.currentplot and self.currentplot != new_selection:
                self.currentplot.canvas.figure.axes[0].set_title(self.currentplot._original_title, fontsize=12, color='k')
                self.currentplot.canvas.draw()

            # Update the newly selected figure
            self.currentplot = new_selection
            self.currentplot.canvas.figure.axes[0].set_title(f"Active Plot — {self.currentplot._original_title}", fontsize=14, color='red')
            self.currentplot.canvas.draw()  # ✅ Refresh figure

    def add_to_existing_plot(self):
        """Add new data to the currently selected plot with unique color and marker."""
        if self.currentplot is None:
            messagebox.showerror("Error", "No active plot selected. Click on a plot window first.")
            return

        x = self.x_entry.get().strip()
        y = self.y_entry.get().strip()
        monitor = self.monitor_entry.get().strip() if self.monitor_entry.get().strip() else None
        constraints = self.parse_constraints(self.constraints_1d)
        filename = self.selected_files_1d if self.selected_files_1d else 'all'
        label = str(self.constraints_1d) if self.constraints_1d else "No Constraint"

        df_reduced=self.apply_constraints(self.dataframe, constraints).copy(deep=True)
        binning = self.get_binning(x, self.bin_entry, df=df_reduced)

        try:
            data = convertto1Ddata(
                x, y, df_reduced, Moncol=monitor, binning=binning, filename=filename
            )

            plt.figure(self.currentplot.number)  # ✅ Use the selected figure

            # Pick a unique color in a cycling manner
            color = self.colors[self.color_index]  # ✅ Cycle colors
            self.color_index = (self.color_index + 1) % len(self.colors)  # ✅ Move to the next color

            # Pick a random marker
            marker = random.choice(self.symbols)  # ✅ Random marker selection

            # Add the new plot to the current figure
            plt.errorbar(
                data[data.columns[0]], data[data.columns[1]], yerr=np.nan_to_num(data[data.columns[2]], nan=0),
                fmt=f"{color}{marker}-", capsize=2, markersize=5, label=label
            )

            plt.legend()
            plt.draw()  # ✅ Update the plot

        except Exception as e:
            messagebox.showerror("Error", f"Error in adding to plot: {e}")

    def plot_2d(self):
        """Handle 2D plotting."""
        if self.dataframe is None:
            messagebox.showerror("Error", "No data loaded. Load data before plotting.")
            return

        def parse_smoothing(smoothing_input):
            """Parse smoothing input as a float or tuple of floats."""
            if not smoothing_input:
                return None
            try:
                if ',' in smoothing_input:
                    return tuple(map(float, smoothing_input.split(",")))
                return float(smoothing_input)
            except ValueError:
                messagebox.showerror("Error", f"Invalid smoothing value: {smoothing_input}")
                return None

        x = self.x2_entry.get().strip()
        y = self.y2_entry.get().strip()
        z = self.z_entry.get().strip()
        monitor = self.monitor2_entry.get().strip() if self.monitor2_entry.get().strip() else None
        binx = int(self.binx_entry.get()) if self.binx_entry.get() else 100
        biny = int(self.biny_entry.get()) if self.biny_entry.get() else 100
        smoothing = parse_smoothing(self.smoothing_entry.get())

        try:
            max_hole_size = float(self.max_hole_entry.get()) if self.max_hole_entry.get() else None
        except ValueError:
            messagebox.showerror("Error", f"Invalid max hole size: {self.max_hole_entry.get()}")
            return

        constraints = self.parse_constraints(self.constraints_2d)
        filename = self.selected_files_2d if self.selected_files_2d else 'all'

        try:
            # Generate 2D data
            df_temp=self.dataframe.copy(deep=True)
            data = convertto2Ddata(
                x, y, z, df_temp, *constraints, Moncol=monitor, filename=filename
            )

            # Set title with constraints (None if no constraints)
            title = str(self.constraints_2d) if self.constraints_2d else None

            # Call the modified plotting function with title
            plt.figure()
            plot2D_with_hole_filling_and_weighted_smoothing(
                data, gaussian_sigma=smoothing, gridx=binx, gridy=biny, max_hole_size=max_hole_size, title=title
            )

        except Exception as e:
            messagebox.showerror("Error", f"Error in 2D plotting: {e}")

    def export_2d(self):
        """Export 2D binned data (e.g., Q vs E with intensity) to CSV or ASCII format."""

        # ✅ Ensure data has been loaded before attempting to export
        if self.dataframe is None:
            messagebox.showerror("Error", "No data loaded. Load data before exporting.")
            return
            
        # ✅ Ask user to choose a file path to export to
        file_path = filedialog.asksaveasfilename(
            defaultextension=".dat",
            filetypes=[
                ("ASCII text files", "*.dat"),
                ("CSV files", "*.csv"),
                ("All files", "*.*")
            ]
        )

        # ❌ If the user cancels the save dialog, exit quietly
        if not file_path:
            return
        
        # ✅ Try generating the 2D data
        try:
            # ✅ Read user inputs for axes
            x = self.x2_entry.get().strip()
            y = self.y2_entry.get().strip()
            z = self.z_entry.get().strip()

            # ✅ Read optional monitor column
            monitor = self.monitor2_entry.get().strip()
            monitor = monitor if monitor else None

            # ✅ Parse any additional data constraints from the GUI
            constraints = self.parse_constraints(self.constraints_2d)

            # ✅ Get subset of filenames being plotted/exported (or 'all')
            filename = self.selected_files_2d if self.selected_files_2d else 'all'

            # Apply constraints before generating binned 2D data
            df_reduced=self.apply_constraints(self.dataframe, constraints).copy(deep=True)

            # ✅ Generate binning tuples: (min, max, num_bins)
            binx = self.get_binning(x,self.binx_entry, df=df_reduced)
            biny = self.get_binning(y,self.biny_entry, df=df_reduced)

            # ✅ Generate the actual 2D binned data (a DataFrame)
            data = convertto2Ddata(
                x, y, z,
                df_reduced,
                Moncol=monitor,
                binx=binx,
                biny=biny,
                filename=filename
            )


        except Exception as e:
            # ❌ If anything goes wrong (bad axis name, invalid bin number, etc.)
            messagebox.showerror("Export Failed", f"Failed to generate 2D data:\n{e}")
            return

        # ✅ Try exporting the DataFrame to file (CSV or ASCII format)
        try:
            if file_path.endswith(".csv"):
                # Export in CSV format (comma-separated)
                data.to_csv(file_path, index=False, float_format="%.8f", na_rep="NaN")
            else:
                # Export in ASCII format (tab-delimited)
                data.to_csv(file_path, sep='\t', index=False, float_format="%.8f", na_rep="NaN")

            # ✅ Notify user of success
            messagebox.showinfo("Export Successful", f"Data exported to:\n{file_path}")

        except Exception as e:
            # ❌ Catch file I/O errors (e.g., file locked, permission error)
            messagebox.showerror("Export Failed", f"Failed to export file:\n{e}")


    def load_data(self):
        """Validate and load data using threading & a cancel button."""
        try:
            self.run_numbers = []
            for i, raw_value in enumerate(self.run_inputs):
                if raw_value.lower() == "all":
                    self.run_numbers.append("all")
                elif raw_value.isdigit():
                    self.run_numbers.append(int(raw_value))
                else:
                    try:
                        self.run_numbers.append([int(val.strip()) for val in raw_value.split(",")])
                    except ValueError:
                        messagebox.showerror("Error", f"Invalid run number format for file {i + 1}: {raw_value}")
                        return

            parameters = [param.strip() for param in self.param_entry.get().split(",") if param.strip()]
            if len(self.run_numbers) != len(self.files):
                messagebox.showerror("Error", "Run numbers must be provided for each file!")
                return

            # Create progress window
            progress_window = tk.Toplevel(self)
            progress_window.title("Loading Progress")

            progress_labels = {}
            for filename in self.files:
                lbl = ttk.Label(progress_window, text=f"{os.path.basename(filename)}: 0/? runs", font=("Arial", 12))
                lbl.pack(pady=5)
                progress_labels[filename] = lbl

            self.continue_loading = {"status": True}
            self.tracker = [None, 0]
            self.load_failed = False

            # Cancel button
            def cancel_loading():
                self.continue_loading["status"] = False
                cancel_btn.config(text="Cancelling...", state=tk.DISABLED)

            cancel_btn = ttk.Button(progress_window, text="Cancel", command=cancel_loading)
            cancel_btn.pack(pady=15)

            result_container = {}  # Local container, not part of self.

            def load_files():
                try:
                    result = openfilelist(
                        self.files, parameters, self.run_numbers,
                        channel_to_phi_map=channel_to_phi_map,
                        van=MADparams["van"],
                        bad_channels=MADparams["bad_channels"],
                        tracker=self.tracker,
                        continue_loading=self.continue_loading
                    )
                    result_container["data"] = result  # Always store result
                except Exception as e:
                    self.load_failed = True
                    self.load_error_message = str(e)
                    result_container["data"] = None

            self.load_thread = threading.Thread(target=load_files)
            self.load_thread.start()

            # Pass container to updater
            self.after(500, self.update_progress, progress_window, progress_labels, result_container)

        except Exception as e:
            messagebox.showerror("Error", f"Error loading data: {e}")



    def update_progress(self, progress_window, progress_labels, result_container):
        if self.load_thread.is_alive():
            if self.tracker[0] is not None:
                filename = self.tracker[0]
                current_run = self.tracker[1]
                run_info = self.run_numbers[self.files.index(filename)]
                total_runs = "∞" if run_info == "all" else len(run_info) if isinstance(run_info, list) else 1
                progress_labels[filename].config(text=f"{os.path.basename(filename)}: {current_run}/{total_runs} runs")

            self.after(500, self.update_progress, progress_window, progress_labels, result_container)

        elif self.load_failed:
            messagebox.showerror("Load Failed", f"An error occurred during loading:\n\n{self.load_error_message}")
            progress_window.destroy()

        else:
            result = result_container.get("data")
            if result is not None and not result.empty:
                self.dataframe = result
                if not self.continue_loading["status"]:
                    messagebox.showinfo("Partial Load", f"Loading was cancelled.\nPartial data loaded: {len(self.dataframe)} rows.")
                else:
                    messagebox.showinfo("Success", f"Data loaded successfully! {len(self.dataframe)} rows loaded.")
            else:
                messagebox.showwarning("No Data", "No usable data was loaded.")
            progress_window.destroy()



    def refresh_constraints_display(self, target):
        """Refresh constraints for the 1D or 2D plot tab."""
        if target == "1D":
            frame = self.constraints_frame_1d
            constraints = self.constraints_1d
            delete_func = self.delete_constraint_1d
        elif target == "2D":
            frame = self.constraints_frame_2d
            constraints = self.constraints_2d
            delete_func = self.delete_constraint_2d
        
        # Clear existing widgets
        for widget in frame.winfo_children():
            widget.destroy()
    
        # Rebuild constraint list
        for idx, (parameter, constraint) in enumerate(constraints):
            ttk.Label(frame, text=f"{parameter} = {constraint}").grid(row=idx, column=0, sticky="w", padx=5, pady=5)
            ttk.Button(
                frame,
                text="Delete",
                command=lambda idx=idx: delete_func(idx)
            ).grid(row=idx, column=1, padx=5, pady=5)
    
    def delete_constraint_1d(self, index):
        """Delete a constraint from the 1D list."""
        del self.constraints_1d[index]
        self.refresh_constraints_display("1D")
    
    def delete_constraint_2d(self, index):
        """Delete a constraint from the 2D list."""
        del self.constraints_2d[index]
        self.refresh_constraints_display("2D")

        
    def select_files(self, target):
        """Handle file selection for plotting."""
        if not self.files:
            messagebox.showerror("Error", "No files have been loaded. Please load files first.")
            return

        # Create a dialog for file selection
        file_selection_window = tk.Toplevel(self)
        file_selection_window.title(f"Select Data Files for {target} Plot")
        file_selection_window.geometry("800x400")
        file_selection_window.resizable(True, True)

        ttk.Label(file_selection_window, text="Select Files to Plot:").pack(pady=10)

        # Use a Frame for better control over layout
        listbox_frame = ttk.Frame(file_selection_window)
        listbox_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # Add Listbox and Scrollbar inside the frame
        scrollbar_x = tk.Scrollbar(listbox_frame, orient=tk.HORIZONTAL)
        scrollbar_y = tk.Scrollbar(listbox_frame, orient=tk.VERTICAL)

        file_listbox = tk.Listbox(
            listbox_frame,
            selectmode=tk.MULTIPLE,
            xscrollcommand=scrollbar_x.set,
            yscrollcommand=scrollbar_y.set
        )
        file_listbox.grid(row=0, column=0, sticky="nsew")

        # Configure scrollbars
        scrollbar_x.config(command=file_listbox.xview)
        scrollbar_y.config(command=file_listbox.yview)
        scrollbar_x.grid(row=1, column=0, sticky="ew")
        scrollbar_y.grid(row=0, column=1, sticky="ns")

        # Make listbox expand with the window
        listbox_frame.columnconfigure(0, weight=1)
        listbox_frame.rowconfigure(0, weight=1)

        # Populate the listbox with the loaded files
        for file in self.files:
            file_listbox.insert(tk.END, file)

        def confirm_selection():
            selected_indices = file_listbox.curselection()
            selected_files = [self.files[i] for i in selected_indices]

            # Store full paths for processing
            filenames = selected_files if selected_files else []

            # Format filenames for display (limit to 3, then add "...")
            max_display = 3
            if len(selected_files) > max_display:
                display_filenames = [os.path.basename(file) for file in selected_files[:max_display]]
                display_filenames.append("...")  # Properly append "..."
            else:
                display_filenames = [os.path.basename(file) for file in selected_files]

            # Update the correct label based on target
            if target == "1D":
                self.selected_files_1d = filenames
                self.selected_files_label.config(text=", ".join(display_filenames))
            elif target == "2D":
                self.selected_files_2d = filenames
                self.selected_files_label_2d.config(text=", ".join(display_filenames))

            file_selection_window.destroy()

        ttk.Button(file_selection_window, text="Confirm", command=confirm_selection).pack(pady=10)

    def apply_UB_matrix(self):
        """
        Apply the UB matrix to convert the data to reciprocal space coordinates.

        Checks for required columns and applies the UB matrix transformation. 
        Provides feedback about missing data or successful transformation.

        Parameters:
            None

        Returns:
            None
        """
        if self.dataframe is None:
            messagebox.showerror("Error", "No files have been loaded. Please load files first.")
            return

        # Check if required columns exist
        required_columns = {'phi.rb', 'psi.rb', 'chi.rb', 'eta.rb'}
        if not required_columns.issubset(self.dataframe.columns):
            missing_columns = required_columns - set(self.dataframe.columns)
            messagebox.showerror("Error", f"Missing columns: {missing_columns}. These are required for transformation.")
            return

        # Apply the UB matrix transformation
        try:
            self.dataframe = viewsc(
                self.dataframe,
                'phi.rb','psi.rb','chi.rb','eta.rb', #name of the columns for phi,psi,chi,eta
                UB=self.ub  # UB matrix
            )
        except Exception as e:
            messagebox.showerror("Error", f"Error during UB matrix transformation: {e}")
            return

        # Provide feedback about the transformation
        if self.ub is None:
            messagebox.showwarning("Warning", "Transformation applied, but no UB matrix loaded. Conversion to hkl is incomplete.")
        else:
            messagebox.showinfo("Success", "Data successfully transformed into hkl coordinates.")


    def calculate_ub(self):
        """Calculate the UB matrix using the crystal structure and UB matrix inputs."""
        try:
            # Parse crystal structure inputs
            crystal_params = {key: float(entry.get()) for key, entry in self.crystal_inputs.items()}
            a, b, c = crystal_params["a"], crystal_params["b"], crystal_params["c"]
            alpha, beta, gamma = crystal_params["alpha"], crystal_params["beta"], crystal_params["gamma"]
            
            # Create the crystal object
            crystal = Crystal(a, b, c, alpha, beta, gamma)
            
            # Parse UB matrix inputs
            Q1 = list(map(float, self.ub_inputs["Q1"].get().split(",")))
            angle1 = list(map(float, self.ub_inputs["angle1"].get().split(",")))
            Q2 = list(map(float, self.ub_inputs["Q2"].get().split(",")))
            angle2 = list(map(float, self.ub_inputs["angle2"].get().split(",")))
            
            if len(Q1) != 3 or len(angle1) != 4 or len(Q2) != 3 or len(angle2) != 4:
                raise ValueError("Invalid dimensions for Q1, angle1, Q2, or angle2.")
            
            # Create UB matrix
            self.ub = UB(crystal, Q1, angle1, Q2, angle2)
            
            messagebox.showinfo("Success", "UB Matrix calculated successfully!")
            print("UB Matrix:", self.ub)

        except ValueError as e:
            messagebox.showerror("Error", f"Input error: {e}")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")

# Run the GUI
if __name__ == "__main__":
    app = FullMAD800GUI()
    app.mainloop()