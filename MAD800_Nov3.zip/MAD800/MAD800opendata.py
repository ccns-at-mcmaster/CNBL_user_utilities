import numpy as np
import pandas as pd
import warnings
import os


# Dictionary to map shorthand parameter names to their names in the metadata
paramsdict = {
    'eta.rb': 'eta',
    'chi.rb': 'chi',
    'phi.rb': 'phi',
    'psi.rb': 'psi',
    'temp.rb0': 'TEMPERATURE 0',
    'temp.rb1': 'TEMPERATURE 1',
    'temp.rb2': 'TEMPERATURE 2',
    'temp.rb3': 'TEMPERATURE 3',
    'sl.rb': 'sl',
    'sr.rb': 'sr',
    'st.rb': 'st',
    'sb.rb': 'sb',
    'x_sample.rb': 'x_sample',
    'y_sample.rb': 'y_sample'
}

# List of column names that should contain integer values
integerparams = ['step', 'Run', 'channel']

def checkstring(str1):
    """
    Creates a function to check if a substring exists in a string.

    Parameters:
        str1 (str): The substring to search for.

    Returns:
        function: A function that takes a string and checks if `str1` is in it.
    """
    return lambda str2: str1 in str2


def getmetadata(filename):
    """
    Extract metadata and headings from a file.

    Parameters:
        filename (str): Path to the file.

    Returns:
        tuple: Contains lists of run numbers, separator indices, metadata blocks, 
               headings, data block start indices, and total lines in the file.
    """
    # Lists to store results
    separatoridxall = []    # Indices of lines starting with '***'
    runlistall = []         # List of run numbers
    metadatalst = []        # Metadata blocks
    headinglst = []         # List of headings
    runbeginningidxall = [] # Start indices of data blocks
    total_lines = 0         # Total number of lines in the file

    # Temporary variables for processing
    current_metadata = []   # Tracks current metadata block
    separator_found = False # Flag for metadata block detection
    heading_found = False   # Flag for heading line detection

    # Process the file line by line
    with open(filename, 'r') as data:
        for idx, line in enumerate(data):
            total_lines += 1

            if line.startswith('***'):  # Start of a metadata block
                separatoridxall.append(idx)
                if current_metadata:
                    metadatalst.append(current_metadata)
                current_metadata = []
                separator_found = True
                heading_found = False

            elif line == '\n':  # End of a metadata block
                runbeginningidxall.append(idx + 3)
                heading_found = True
                separator_found = False

            elif heading_found:  # Process heading after empty line
                headinglst.append(['step'] + list(filter(('|').__ne__, line.split())))
                heading_found = False

            elif separator_found:  # Add to current metadata block
                current_metadata.append(line)

            # Extract run number from the first line of metadata block
            if separator_found and len(current_metadata) == 1:
                try:
                    run_number = int(current_metadata[0].split(':')[1])
                    runlistall.append(run_number)
                except (IndexError, ValueError):
                    raise ValueError(f"Error parsing run number at line {idx}: {line.strip()}")

        if current_metadata:  # Append last metadata block if file ends abruptly
            metadatalst.append(current_metadata)

    return runlistall, separatoridxall, metadatalst, headinglst, runbeginningidxall, total_lines


def getparametervalue(parameter, metadata):
    """
    Extract parameter value from metadata.

    Parameters:
        parameter (str): The parameter name to extract.
        metadata (list): Metadata block.

    Returns:
        float: Extracted parameter value or NaN if not found.
    """
    parameter_name = paramsdict.get(parameter, parameter)  # Map to full name if applicable
    metadata_line = [
        line for line in metadata
        if checkstring('=')(line) and checkstring(parameter_name)(line)
    ]
    #metadata_line = list(filter(checkstring(parameter_name), metadata))
    if metadata_line:
        return float(metadata_line[0].split(parameter_name)[-1].split()[1])  # Extract value
    return np.nan  # Return NaN if not found

def fast_mixed_int_nan(col):
    # Convert to numeric (invalid entries → NaN)
    # col_numeric = pd.to_numeric(col, errors='coerce').to_numpy(dtype='float64')
    # To accommodate older Pandas version <1.5
    col_numeric = pd.to_numeric(col, errors='coerce').astype('float64',copy=False).to_numpy()

    # Preallocate object array
    result = np.empty_like(col_numeric, dtype=object)

    # Vectorized assignment
    valid = ~np.isnan(col_numeric)
    result[valid] = col_numeric[valid].astype(int)
    result[~valid] = np.nan

    return result

def enforce_dtypes(df, int_columns):
    df = df.copy()
    int_columns = set(int_columns)

    for col in int_columns:
        if col in df.columns:
            df[col] = fast_mixed_int_nan(df[col])

    # All other columns: convert to float
    other_cols = [c for c in df.columns if c not in int_columns]
    for col in other_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce').astype(float)

    return df



def openfilenew(filename, parameters, Runs='all', channel_to_phi_map=None, van=None, bad_channels=None, tracker=None, continue_loading={"status": True}):
    """
    Opens specific runs from a file and returns a DataFrame with selected parameters.

    Parameters:
        filename (str): Path to the file.
        parameters (list): List of parameters to extract from each run.
        Runs (str, int, or list): Runs to process. Use 'all' to process all runs.
        channel_to_phi_map (list or None): Optional mapping list to convert 'channel' to 'phi.rb'.
                                           If provided and 'phi.rb' is not already in the data,
                                           it will be added based on this map.
        van (list or None): Optional list of Vanadium monitor values (same length as number of channels).
                            If provided, used to compute 'I_norm' as det.cnt / van[channel - 1].
        bad_channels (list or None): Optional list of bad channels. If provided, any rows with matching
                                     channel numbers will have 'det.cnt' set to NaN before normalization.
        tracker (list or None): Optional 2-element list used to track [current_filename, current_run_index].
                                Useful for GUI progress updates or cancelation.
        continue_loading (dict): Dictionary with key "status" used to control whether loading should continue.
                                 If continue_loading["status"] is False, the loop will exit early.

    Returns:
        pd.DataFrame: Combined DataFrame containing all selected runs and parameters.
                      Additional columns like 'phi.rb', 'van', and 'I_norm' may be included
                      if their corresponding options are provided.
    """

    # Normalize path for consistency across OS (Windows, Linux, macOS)
    filename_full = os.path.normpath(os.path.abspath(filename))  

    # Extract metadata
    runlistall, separatoridxall, metadatalst, headinglst, runbeginningidxall, totallines = getmetadata(filename)
    dflist = []

    # Determine which runs to process
    runlist = runlistall if Runs == 'all' else ([Runs] if isinstance(Runs, int) else Runs)

    # Set tracker file
    if tracker is not None:
        tracker[0] = filename_full  

    # Process each run
    for current_run_idx, run in enumerate(runlist):

        if not continue_loading["status"]:  # ✅ Check cancel signal
            print(f"Loading cancelled in {filename_full}, Run {run}")
            df = pd.DataFrame(index=[filename_full], columns=parameters)  # ✅ Preserve structure
            df['Run'] = run
            dflist.append(df)  # ✅ Add empty DataFrame to the list
            break  # ✅ Stop further processing

        if tracker is not None:
            tracker[1] = current_run_idx + 1  # Update run tracker

        idx = runlistall.index(run)
        heading = headinglst[idx]

        # Separate parameters based on availability in the heading
        params_inheading = list(set(parameters) & set(heading))
        params_notinheading = list(set(parameters) - set(params_inheading))

        # Handle empty runs
        if runbeginningidxall[idx] >= totallines or (run != runlistall[-1] and runbeginningidxall[idx] >= separatoridxall[idx + 1]):
            df = pd.DataFrame(index=[filename_full], columns=parameters)
            df['Run'] = run
            warnings.warn(f"Run {run} in {filename_full} is empty!")
        else:
            # Determine lines to read
            start_line = runbeginningidxall[idx]
            end_line = separatoridxall[idx + 1] if run != runlistall[-1] else totallines

            # Read the required portion of the file
            dftemp = pd.read_csv(
                filename, 
                skiprows=range(start_line),
                nrows=end_line - start_line if end_line else None,
                names=heading,
                header=None,
                sep='|'
            )

            df = dftemp[params_inheading]

            # Add parameters not in heading
            for param in params_notinheading:
                param_value = getparametervalue(param, metadatalst[idx])
                df.loc[:, param] = param_value
                if pd.isna(param_value):
                    warnings.warn(f"Run {run} in {filename_full} does not contain {param}!")

            df['Run'] = run
            df.index = [filename_full] * len(df)  # ✅ Use normalized full path as index

        dflist.append(df)

    # Combine all runs into a single DataFrame
    df_final = pd.concat(dflist)

    # Normalize DataFrame index to match GUI selections
    df_final.index = df_final.index.map(os.path.normpath)  # ✅ Normalize index to avoid mismatches

    if 'channel' in df_final.columns:
        # Safely convert to nullable Int64 dtype to enable integer ops with missing values
        df_final['channel'] = pd.to_numeric(df_final['channel'], errors='coerce').astype('Int64')

        # ✅ Define valid mask using .notna(), which works for both pd.NA and np.nan
        valid_mask = df_final['channel'].notna().to_numpy()
        index_array = df_final['channel'][valid_mask].to_numpy(dtype='int64')

        # ✅ Mask bad channels before normalization
        if bad_channels is not None and 'det.cnt' in df_final.columns:
            df_final.loc[df_final['channel'].isin(bad_channels), 'det.cnt'] = np.nan

        # ✅ Vanadium normalization
        if van is not None and 'det.cnt' in df_final.columns:
            van_array = np.asarray(van)
            van_col = np.full(df_final.shape[0], np.nan, dtype=np.float64)
            van_col[valid_mask] = van_array[index_array - 1]
            df_final['van'] = van_col
            df_final['I_norm'] = df_final['det.cnt'] * df_final['van']

        # ✅ Channel to phi.rb mapping
        if channel_to_phi_map is not None and 'phi.rb' not in df_final.columns:
            phi_array = np.asarray(channel_to_phi_map)
            phi_rb_col = np.full(df_final.shape[0], np.nan, dtype=np.float64)
            phi_rb_col[valid_mask] = phi_array[index_array - 1]
            df_final['phi.rb'] = phi_rb_col

    
    ## Masking infinities
    df_final.replace([np.inf, -np.inf], np.nan, inplace=True)
    
    ## Ensure all the entries are of the right dtypes
    df_final = enforce_dtypes(df_final, integerparams)

    return df_final  # Return the final DataFrame


                

def openfilelist(filelist, parameters, runlist, channel_to_phi_map=None, van=None, bad_channels=None, tracker=None, continue_loading={"status": True}):
    """
    Opens a list of .adata files and extracts specified parameters for given runs.

    Parameters:
        filelist (list of str): List of file paths to the .adata files.
        parameters (list of str): List of parameter names to extract from each file.
        runlist (list): List specifying the runs to extract for each file. Each element should be either
                        'all' or a list of integers (e.g., [1, 2, 5]).
        channel_to_phi_map (list or None): Optional mapping list to convert 'channel' to 'phi.rb'.
        van (list or None): Optional list of Vanadium monitor values for computing 'I_norm'.
        bad_channels (list or None): Optional list of bad channel numbers. Corresponding 'det.cnt' entries 
                                     will be set to NaN.
        tracker (list or None): Optional tracker list for monitoring progress (e.g., in a GUI).
        continue_loading (dict): Dictionary with key "status" used to allow interrupting processing 
                                 (e.g., {"status": False} to cancel).

    Returns:
        pd.DataFrame: A combined DataFrame containing all selected parameters and runs for all files.

    Notes:
        This function internally uses `openfilenew()` to process each file.
    """

    dffinal = []  # List to collect DataFrames for each file

    # Process each file and its corresponding run list
    for i in range(len(filelist)):
        # Use openfilenew to process each file
        dftemp = openfilenew(filelist[i], parameters, Runs=runlist[i], channel_to_phi_map=channel_to_phi_map, van=van, bad_channels=bad_channels, tracker=tracker, continue_loading=continue_loading)
        dffinal.append(dftemp)  # Append the resulting DataFrame to the list

    # Concatenate all DataFrames without resetting the index
    return pd.concat(dffinal)  # Preserve the index (e.g., filenames)

                   
def openfilesfromcsv(csvfile, channel_to_phi_map=None, van=None, bad_channels=None, tracker=None, continue_loading={"status": True}):
    """
    Opens and processes a list of .adata files based on instructions in a CSV file.

    Parameters:
        csvfile (str): Path to a CSV file that specifies the parameter list and which runs to extract from which files.
        channel_to_phi_map (list or None): Optional mapping list to convert 'channel' to 'phi.rb'.
        van (list or None): Optional list of Vanadium monitor values for computing 'I_norm'.
        bad_channels (list or None): Optional list of bad channel numbers. Corresponding 'det.cnt' entries 
                                     will be set to NaN.
        tracker (list or None): Optional tracker list for monitoring progress (e.g., in a GUI).
        continue_loading (dict): Dictionary with key "status" used to allow interrupting processing 
                                 (e.g., {"status": False} to cancel).

    Returns:
        pd.DataFrame: A combined DataFrame of selected parameters and runs for all files specified in the CSV.

    Notes:
        The CSV file must have the following format:
        - First row, second column: Comma-separated list of parameter names
        - Subsequent rows:
            - Column 0: Filename
            - Column 1: Run list (e.g., "all", "1,2,4-6")

        Example:
            file1.ad, E,det.cnt
            file1.ad, all
            file2.ad, 1-5,7
    """

    df = pd.read_csv(csvfile, header=None)
    
    # Extract parameters
    params = df.iloc[0, 1].split(',')
    
    # Extract file list and run list
    filelist = df[0][1:].tolist()

    def process_run_entry(entry):
        if entry=='all':
            return 'all'
        else:
            ranges = entry.split(',')
            result = []
            for r in ranges:
                if '-' in r:
                    start, end = map(int, r.split('-'))
                    result.extend(range(start, end + 1))
                else:
                    result.append(int(r))
            return sorted(set(result))
    
    runlist = [process_run_entry(entry) for entry in df[1][1:].tolist()]

    
    # Placeholder for openfilelist logic
    df = openfilelist(filelist, params, runlist, channel_to_phi_map=channel_to_phi_map, van=van, bad_channels=bad_channels, tracker=tracker, continue_loading=continue_loading)
    return df



