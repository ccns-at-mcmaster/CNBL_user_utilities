import numpy as np

# Utility functions for trigonometric calculations (angle in radians)
def cot(angle):
    return 1 / np.tan(angle)

def sec(angle):
    return 1 / np.cos(angle)

def csc(angle):
    return 1 / np.sin(angle)

class Crystal:
    """
    A class representing a crystal lattice.

    Attributes:
        A1c (numpy.ndarray, in Å): Cartesian coordinates of the first lattice vector (A1).
        A2c (numpy.ndarray, in Å): Cartesian coordinates of the second lattice vector (A2).
        A3c (numpy.ndarray, in Å): Cartesian coordinates of the third lattice vector (A3).
        vol (float, in Å³): Volume of the unit cell, calculated using the lattice vectors in Cartesian coordinates.
        B1c (numpy.ndarray, in 1/Å): Cartesian coordinates of the first reciprocal lattice vector (B1).
        B2c (numpy.ndarray, in 1/Å): Cartesian coordinates of the second reciprocal lattice vector (B2).
        B3c (numpy.ndarray, in 1/Å): Cartesian coordinates of the third reciprocal lattice vector (B3).
    """

    def __init__(self, a, b, c, alpha, beta, gamma):
        """
        Initializes a crystal lattice with the given parameters.

        Args:
            a (float, in Å): Length of the first lattice vector.
            b (float, in Å): Length of the second lattice vector.
            c (float, in Å): Length of the third lattice vector.
            alpha (float, in degrees): Angle between b and c.
            beta (float, in degrees): Angle between a and c.
            gamma (float, in degrees): Angle between a and b.
        """
        # Convert angles to radians
        alpha_rad = np.radians(alpha)
        beta_rad = np.radians(beta)
        gamma_rad = np.radians(gamma)

        # Conversion matrix between lattice and Cartesian coordinates
        M = np.array([
            [a * np.sin(beta_rad) * np.sqrt(1 - (cot(alpha_rad) * cot(beta_rad) - csc(alpha_rad) * csc(beta_rad) * np.cos(gamma_rad))**2), 0, 0],
            [a * csc(alpha_rad) * np.cos(gamma_rad) - a * cot(alpha_rad) * np.cos(beta_rad), b * np.sin(alpha_rad), 0],
            [a * np.cos(beta_rad), b * np.cos(alpha_rad), c]
        ])

        # Lattice vectors in Cartesian coordinates
        self.A1c = np.matmul(M, [1, 0, 0])  # Lattice vector A1 in Cartesian coordinates (Å)
        self.A2c = np.matmul(M, [0, 1, 0])  # Lattice vector A2 in Cartesian coordinates (Å)
        self.A3c = np.matmul(M, [0, 0, 1])  # Lattice vector A3 in Cartesian coordinates (Å)

        # Volume of the unit cell
        self.vol = np.dot(self.A1c, np.cross(self.A2c, self.A3c))  # Unit cell volume (Å³)

        # Reciprocal lattice vectors in Cartesian coordinates
        self.B1c = 2 * np.pi * np.cross(self.A2c, self.A3c) / self.vol  # Reciprocal lattice vector B1 (1/Å)
        self.B2c = 2 * np.pi * np.cross(self.A3c, self.A1c) / self.vol  # Reciprocal lattice vector B2 (1/Å)
        self.B3c = 2 * np.pi * np.cross(self.A1c, self.A2c) / self.vol  # Reciprocal lattice vector B3 (1/Å)

    def rlutocartesian(self, u):
        """
        Converts a reciprocal lattice vector from lattice units to Cartesian coordinates.

        Args:
            u (list or numpy.ndarray): Reciprocal lattice vector (h, k, l) in lattice units.

        Returns:
            numpy.ndarray, in 1/Å: Cartesian coordinates of the input vector.
        """
        return u[0] * self.B1c + u[1] * self.B2c + u[2] * self.B3c

    def angle(self, u1, u2):
        """
        Calculates the angle (in degrees) between two reciprocal lattice vectors.

        Args:
            u1 (list or numpy.ndarray): First reciprocal lattice vector (h1, k1, l1) in lattice units.
            u2 (list or numpy.ndarray): Second reciprocal lattice vector (h2, k2, l2) in lattice units.

        Returns:
            float, in degrees: Angle between the two vectors.
        """
        u1c = self.rlutocartesian(u1)
        u2c = self.rlutocartesian(u2)
        dot_product = np.dot(u1c, u2c)
        magnitudes = np.sqrt(np.dot(u1c, u1c) * np.dot(u2c, u2c))
        return np.rad2deg(np.arccos(dot_product / magnitudes))

    def twotheta(self, Q, ki):
        """
        Calculates the 2-theta angle (in degrees) for a given reflection.

        Args:
            Q (list or numpy.ndarray): Miller index of the reflection (h, k, l).
            ki (float, in 1/Å): Magnitude of the wave vector of the incident beam.

        Returns:
            float, in degrees: 2-theta angle.
        """
        reciprocal_vector = self.rlutocartesian(Q)
        Qmag = np.linalg.norm(reciprocal_vector)
        return np.rad2deg(2 * np.arcsin(Qmag / (2 * ki)))
