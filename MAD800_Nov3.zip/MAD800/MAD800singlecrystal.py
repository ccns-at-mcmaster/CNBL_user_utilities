import json
import os
import numpy as np
import pandas as pd
from scipy.spatial.transform import Rotation
import warnings
from scipy import optimize

# Get the MAD instrument parameters from 'MAD_instrumental_parameters.json' including
# wavelength (in Å)
# motor offsets on MAD {psi0,eta0,chi0,phi0}
# psi0,eta0,chi0 are the sample goniometer angles for stage-fixed xyz axes to align with the lab XYZ axes: 
# X//ki, Y perp to ki in the scattering plane, Z perp to scattering plane
# since x/y are arbitrary, psi0 and eta0 are by default zeros
# phi0 is motor angle when the detector is aligned with ki
# an integer +1 (ACW)/-1(CW) specifying the direction of rotation for positive motor angle

# Load the MAD configuration file
current_dir = os.path.dirname(__file__)
json_file_path = os.path.join(current_dir, "MAD_instrumental_parameters.json")

with open(json_file_path, "r") as f:
    MADparams = json.load(f)

# Print the parameters when loaded the first time
print("Initial MAD parameters loaded:")
print(json.dumps(MADparams, indent=4))  # Pretty-print the initial parameters

# Compute ki from Lambda
ki = 2 * np.pi / MADparams['Lambda']

def channel_to_phi(channel, tth0=0, x0=0, y0=0):
    """
    Convert channel to the phi motor angle.

    Parameters:
        channel (int): The channel value (range: 1 to 800).
        tth0 (float): A constant offset angle in degrees. Default is 0.
        x0 (float): X-axis offset. Default is 0.
        y0 (float): Y-axis offset. Default is 0.

    Returns:
        float: The calculated phi motor angle in degrees.
    """
    # Step 1: Calculate the two-theta (tth) value in radians
    tth = np.radians((800 - channel) * 0.1 + tth0)

    # Step 2: Calculate X and Y positions of the center of the detector
    X = np.cos(tth) + x0
    Y = np.sin(tth) + y0

    # Step 3: Calculate the phi motor angle, assuming a CW rotation correponds to positive value
    phi = np.rad2deg((-1) * np.arctan2(Y, X))

    return phi

channel_to_phi_map=[channel_to_phi(val,tth0=MADparams['tth0'], x0=MADparams['x0'],y0=MADparams['y0']) for val in range(1,801)] # a list mapping channel number (1-800) to the phi motor angle


def resetMADparams(params):
    """
    Update MADparams, recompute ki, and print the updated parameters without modifying the original file.

    Parameters:
        params (dict): A dictionary of new parameters to update in MADparams.
    """
    global MADparams, ki, channel_to_phi_map
    MADparams.update(params)  # Update MADparams with new values
    ki = 2 * np.pi / MADparams['Lambda']  # Recompute ki
    channel_to_phi_map=[channel_to_phi(val,tth0=MADparams['tth0'], x0=MADparams['x0'],y0=MADparams['y0']) for val in range(1,801)] # recompute the conversion list


    # Print updated parameters to the console
    print("Updated MAD parameters:")
    print(json.dumps(MADparams, indent=4))  # Pretty-print the dictionary















def getQlab(Q):
    """
    Compute the two-theta (tth) angle in degrees and the Q-vector in the laboratory frame.

    Args:
        Q (numpy.ndarray or list): A vector representing the scattering vector in reciprocal space.

    Returns:
        tuple:
            - tth (float): The two-theta angle (in degrees) derived from the magnitude of Q.
            - qlab (numpy.ndarray): The Q-vector in the laboratory frame, represented as a 3D array.

    Raises:
        ValueError: If the magnitude of Q exceeds 2 * ki, indicating that Bragg's law cannot be satisfied.
    """
    # Compute the magnitude of Q
    Qlength = np.sqrt(np.dot(Q, Q))

    # Compute the two-theta angle in radians and convert to degrees
    tth = np.arcsin(Qlength / 2 / ki) * 2 * (180 / np.pi)

    # Calculate the Q-vector in the laboratory frame
    qlab = np.array([-np.sin(np.radians(tth / 2.0)), np.cos(np.radians(tth / 2.0)), 0])

    # Check if Bragg's law is violated
    if Qlength > 2 * ki:
        raise ValueError(f"Bragg's law cannot be satisfied!", UserWarning)

    return tth, qlab,qlab*Qlength


def angle12(v1, v2):
    """
    Calculate the angle (in degrees) between two vectors.

    Args:
        v1 (numpy.ndarray): The first vector.
        v2 (numpy.ndarray): The second vector.

    Returns:
        float: The angle between the two vectors in degrees.

    Notes:
        - The angle is calculated using the dot product formula:
          cos(theta) = (v1 · v2) / (|v1| * |v2|)
        - The result is converted from radians to degrees by multiplying by (180 / π).
    """
    return np.arccos(np.dot(v1, v2) / np.sqrt(np.dot(v1, v1) * np.dot(v2, v2))) / np.pi * 180


def normalizeangle(angles):
    """
    Normalize a list of angles to the range (-180, 180] degrees.

    Args:
        angles (list of float): A list of angles in degrees.

    Returns:
        list of float: A list where each angle has been normalized to the range (-180, 180] degrees.
    """

    return [(angle % 360) if (angle % 360) < 180 else angle % 360 - 360 for angle in angles]


def checkMADlimit(angles):
    """
    Check if the given angles are within the predefined motor limits for MAD.

    Args:
        angles (list of float): A list of angles in the form [phi, psi, chi, eta].
            - phi (float): Angle for the phi motor (degrees).
            - psi (float): Angle for the psi motor (degrees).
            - chi (float): Angle for the chi motor (degrees).
            - eta (float): Angle for the eta motor (degrees).

    Returns:
        bool: 
            - True if all angles are within their respective motor limits.
            - False if any angle is outside its motor limit.
    """
    motorlimits=[MADparams['phi_lim'],MADparams['psi_lim'],MADparams['chi_lim'],MADparams['eta_lim']]

    return all(motorlimits[i][0] <= angles[i] <= motorlimits[i][1] for i in range(len(angles)))


def MADtoeuler(psi, chi, eta):
    """
    Convert MAD motor angles (psi, chi, eta) to Euler angles (alpha, beta, gamma)
    in the ZXZ intrinsic rotation sequence.

    Args:
        psi (float): MAD motor angle psi (in degrees).
        chi (float): MAD motor angle chi (in degrees).
        eta (float): MAD motor angle eta (in degrees).

    Returns:
        tuple: Euler angles (alpha, beta, gamma) in degrees corresponding to the
               ZXZ intrinsic rotation sequence.
    """
    alpha = (psi - MADparams['psi0']) * MADparams['rpsi']  # Calculate the first Euler angle
    beta = (chi - MADparams['chi0']) * MADparams['rchi']  # Calculate the second Euler angle
    gamma = (eta - MADparams['eta0']) * MADparams['reta']  # Calculate the third Euler angle
    return alpha, beta, gamma


def eulertoMAD(alpha, beta, gamma):
    """
    Convert Euler angles (alpha, beta, gamma) in the ZXZ intrinsic rotation sequence
    to MAD motor angles (psi, chi, eta).

    Args:
        alpha (float): Euler angle alpha (in degrees).
        beta (float): Euler angle beta (in degrees).
        gamma (float): Euler angle gamma (in degrees).

    Returns:
        tuple: MAD motor angles (psi, chi, eta) in degrees.
    """
    psi = alpha * MADparams['rpsi'] + MADparams['psi0']  # Calculate the MAD psi angle
    chi = beta * MADparams['rchi'] + MADparams['chi0']  # Calculate the MAD chi angle
    eta = gamma * MADparams['reta'] + MADparams['eta0']  # Calculate the MAD eta angle
    return psi, chi, eta

def Rmad(psi, chi, eta):
    """
    Compute the transformation matrix for three rotations in the MAD coordinate system.

    Args:
        psi (float): MAD motor angle psi (in degrees).
        chi (float): MAD motor angle chi (in degrees).
        eta (float): MAD motor angle eta (in degrees).

    Returns:
        scipy.spatial.transform.Rotation: A transformation matrix (or object) representing
        the combined rotations. It acts on a vector in the original `xyz` coordinate system
        and transforms it to its `XYZ` coordinate after the rotation sequence.
    """
    # Convert MAD angles to Euler angles
    alpha, beta, gamma = MADtoeuler(psi, chi, eta)

    # Create the rotation matrix using the ZXZ intrinsic rotation sequence
    Reuler = Rotation.from_euler('ZXZ', [alpha, beta, gamma], degrees=True)

    return Reuler

def angletoQstage(angle):
    """
    Compute the staged-fixed coordinate (in Å) for the Q-transfer based on the motor angles [phi, psi, chi, eta]. 

    Args:
        angle (list of float): A list of angles in the form [phi, psi, chi, eta] (in degrees).
            - phi (float): Rotation angle for the phi motor.
            - psi (float): Rotation angle for the psi motor.
            - chi (float): Rotation angle for the chi motor.
            - eta (float): Rotation angle for the eta motor.

    Returns:
        numpy.ndarray: A 3D vector representing the stage-fixed coordinate in the Q-space.

    Example:
        # Define the necessary constants
        phi0 = 0.0
        rphi = 1.0
        ki = 1.0  # Example incident wave vector magnitude

        # Define angles
        angles = [45, 30, 60, 90]

        # Compute the stage-fixed coordinate
        Qstage = angletoQstage(angles)
        print("Stage-fixed Q-vector:", Qstage)
    """
    # Extract individual angles
    phi, psi, chi, eta = angle

    # Compute the two-theta angle (tth) in radians
    tth = np.radians((phi - MADparams['phi0']) * MADparams['rphi'])

    # Calculate the Q-vector magnitude (Qlength)
    Qlength = 2 * ki * np.sin(tth / 2.0)

    # Compute the Q-vector in the laboratory frame (Qlab)
    Qlab = Qlength * np.array([-np.sin(tth / 2.0), np.cos(tth / 2.0), 0])

    # Apply the rotation for MAD angles to align with stage-fixed coordinates
    R = Rmad(psi, chi, eta)

    # Transform Qlab into the stage-fixed frame
    return R.inv().apply(Qlab)

def viewsc(df, phi, psi, chi, eta, UB=None):
    """
    Converts motor angles to momentum coordinates (HKL) or Q-space vectors.
    
    Parameters:
        df (pd.DataFrame): Input DataFrame containing motor angles.
        phi, psi, chi, eta (str): Column names in the DataFrame for motor angles.
        UB (object, optional): Instance of a class containing the `stagetorlu` method 
                               for converting Q vectors to reciprocal lattice units (HKL).
                               
    Returns:
        pd.DataFrame: an updated DataFrame with calculated Qx, Qy, Qz (and optionally H, K, L).
    """
    # Extract the required columns and convert them to a NumPy array
    angles = df[[phi, psi, chi, eta]].to_numpy()  # Shape: (N, 4)
    
    # Calculate sample angles in the stage-fixed coordinate system
    tth = np.radians((angles[:, 0] - MADparams['phi0']) * MADparams['rphi'])  # Scattering angle, in radians
    alpha = (angles[:, 1] - MADparams['psi0']) * MADparams['rpsi']
    beta = (angles[:, 2] - MADparams['chi0']) * MADparams['rchi']
    gamma = (angles[:, 3] - MADparams['eta0']) * MADparams['reta']
    sample_angles = np.column_stack([alpha, beta, gamma])  # Shape: (N, 3)

    # Generate rotation matrices from sample angles (Euler ZXZ convention)
    rotations = Rotation.from_euler('ZXZ', sample_angles, degrees=True).as_matrix()  # Shape: (N, 3, 3)

    # Calculate Q-lengths in the lab frame
    Qlength = 2 * ki * np.sin(tth / 2.0)  # Magnitude of Q vectors

    # Calculate Qlab (Q vectors in the lab frame)
    sin_tth = np.sin(tth / 2)
    cos_tth = np.cos(tth / 2)
    Qlab = np.column_stack([-sin_tth * Qlength, cos_tth * Qlength, np.zeros_like(tth)])  # Shape: (N, 3)

    # Transform Q vectors from lab frame to stage-fixed coordinate system
    data = np.einsum('ijk,ij->ik', rotations, Qlab)  # Shape: (N, 3)
    columns = ['Qx', 'Qy', 'Qz']

    # If UB is provided, calculate HKL from Qstage
    if UB is not None:
        hkl = UB.stagetorlu(data)  # Convert Qstage to reciprocal lattice units
        data = np.column_stack([data, hkl])  # Add HKL to the data
        columns += ['H', 'K', 'L']

    # append the new columns to the original dataframe
    df[columns]=data
    return df






def caleuler(xyzlab, alphafix=0):
    """
    Calculate the Euler angles (alpha, beta, gamma) for an ZXZ intrinsic rotation sequence if the x,y,z 
    unit vectors of the stage are rotated to [xlab,ylab,zlab]

    Args:
        xyzlab (numpy.ndarray): A 3x3 numpy.ndarray giving [xlab,ylab,zlab].
        alphafix (float, optional): A fixed value for alpha to resolve ambiguity
                                    when z//Z

    Returns:
        list of list: A pair of Euler angle triplets:
            - [alpha1, beta1, gamma1]: Standard ZXZ Euler angles.
            - [alpha2, beta2, gamma2]: Alternative normalized angles where:
                - alpha2 = alpha1 + 180 degrees,
                - beta2 = -beta1,
                - gamma2 = gamma1 + 180 degrees.
                giving the same rotation matrix
    
    Notes:
        - The input array cannot be a list of three vectors, must be numpy.ndarray
        - The function uses `scipy.spatial.transform.Rotation` to compute Euler angles
          from the rotation matrix.
        - If the Z-axis in the original coordinate system is aligned with the Z-axis
          in the transformed system, the rotation matrix cannot uniquely determine
          alpha and gamma (gimbal lock condition).
        - In such cases, the `alphafix` argument is used to resolve the ambiguity by
          assigning a fixed value to alpha, and gamma is adjusted accordingly.
    """
    # Create a rotation object from the transposed matrix
    R = Rotation.from_matrix(xyzlab.T)

    # Handle ambiguous cases using a warning catch
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        alpha1, beta1, gamma1 = R.as_euler('ZXZ', degrees=True)

        if len(w) > 0:
            # Ambiguity detected: Resolve using alphafix
            gamma1 = alpha1+gamma1 - alphafix
            alpha1 = alphafix
            

    # Return both the standard and alternative normalized Euler angles
    return [
        [alpha1, beta1, gamma1],
        normalizeangle([alpha1 + 180, -1 * beta1, gamma1 + 180])
    ]


def calMAD(xyzlab,psifix=0):
    """
    Calculate the sample goniometer angles (psi,chi,eta) for an ZXZ intrinsic rotation sequence if the x,y,z 
    unit vectors of the stage are rotated to [xlab,ylab,zlab]
    """
    alphafix=(psifix-MADparams['psi0'])*MADparams['rpsi']
    SETeuler=caleuler(xyzlab,alphafix=alphafix)
    return [normalizeangle(list(eulertoMAD(Set[0],Set[1],Set[2]))) for Set in SETeuler]   

def calMADchifreeze(Q, chifreeze, psifix=0, xlab=[0, 0, 1]):
    """
    Calculate the MAD motor angles needed to reach a given Q-vector in reciprocal space,
    while fixing the chi angle to a specified value (`chifreeze`).

    Args:
        Q (list or numpy.ndarray): A 3D vector representing the scattering vector in reciprocal space.
        chifreeze (float): The desired fixed value for the chi motor angle (in degrees).
        psifix (float, optional): A fixed value for the psi motor angle (in degrees) for the gimbal lock scenario with z//Z.
        xlab (list or numpy.ndarray, optional): A vector representing the stage-fixed x-axis in the laboratory frame for the gimbal lock scenario with z//Q.
                                                Defaults to [0, 0, 1] (aligned with the Z-axis).

    Returns:
        list of list: A list of possible motor angle solutions, where each solution is a list:
                      [phi, chi, eta, psi].

    Raises:
        UserWarning: If the given Q-vector cannot be reached with the fixed chi value
                     or if the motor limits are exceeded.

    Logic Overview:
        - Calculate beta (angle for fixed chi) and the two-theta (tth) angle.
        - Compute the angle between Q and the Z-axis (`angle_Qz`).
        - If `angle_Qz` indicates Q is not aligned with the Z-axis:
            1. Check geometrical constraints for feasible solutions.
            2. Compute possible rotation scenarios for MAD angles.
        - Handle edge cases where Q is aligned with the Z-axis (gimbal lock conditions where the eta motor is rendered redundant).
        - Filter motor angles to ensure they satisfy MAD motor limits.
        - Return the valid motor angles.
    """
    beta = (chifreeze - MADparams['chi0']) * MADparams['rchi']  # Calculate beta from fixed chi
    tth, Qlabunit, Qlab = getQlab(Q)  # Get two-theta, Qlab unit vector, and Qlab
    phi = tth * MADparams['rphi'] + MADparams['phi0']  # Calculate phi

    angle_Qz = angle12(Q, [0, 0, 1])  # Angle between Q and the Z-axis
    motorangles = []

    # Check if Q is not aligned with the Z-axis
    if 0.01 < angle_Qz < 179.99:
        costheta = np.cos(np.radians(beta)) / np.sin(np.radians(angle_Qz))

        # Check whether the cone of possible z-axes in the lab frame interset the cone defined by chifreeze
        if abs(costheta) <= 1:
            # Two solutions if the two cones interset; one solution if they just touch
            if abs(costheta) == 1:
                theta = np.rad2deg([np.arccos(costheta)])
            else:
                theta = np.rad2deg([np.arccos(costheta), -1 * np.arccos(costheta)])

            zlab0 = np.cos(np.radians(angle_Qz)) * Qlabunit + np.sin(np.radians(angle_Qz)) * np.array([0, 0, 1])

            for thetai in theta:
                R_Q = Rotation.from_rotvec(thetai * Qlabunit, degrees=True)
                zlab = R_Q.apply(zlab0)

                M_stage = np.linalg.inv(np.array([[0, 0, 1], Q, np.cross([0, 0, 1], Q)]).T)
                M_lab = np.array([zlab, Qlab, np.cross(zlab, Qlab)]).T

                xyzlab = np.matmul(M_lab, M_stage).T

                for Set in calMAD(xyzlab, psifix=psifix):
                    if abs(Set[1] - chifreeze) < 0.01:
                        motorangles.append([phi] + Set)
        else:
            warnings.warn(f"Cannot access Q with fixed chi=`{chifreeze}`!", UserWarning)
    
    # The edge case when z//Q, beta must be 90 degrees
    else:
        if angle_Qz < 0.01:
            zlab = Qlabunit
        else:
            zlab = -1 * Qlabunit
        xlab = xlab
        xyzlab = np.array([xlab, np.cross(zlab, xlab), zlab])

        for Set in calMAD(xyzlab, psifix=psifix):
            if abs(Set[1] - chifreeze) < 0.01:
                motorangles.append([phi] + Set)

        if len(motorangles)==0:
            warnings.warn(f"Cannot access Q with fixed chi=`{chifreeze}`!", UserWarning)

    # Check motor limits
    if len(motorangles) > 0:
        motorangles = [Set for Set in motorangles if checkMADlimit(Set)]
        if len(motorangles) == 0:
            warnings.warn(f"Motor limits on MAD exceeded when trying to reach Q!", UserWarning)
    return motorangles


def calMADpsifreeze(Q, psifreeze, xlab=[0, 0, 1]):
    """
    Calculate motor angles to access a reciprocal space vector Q, given a fixed psi value.
    
    Parameters:
        Q: numpy array
            Reciprocal space vector in the lab frame.
        psifreeze: float
            Fixed psi angle.
        xlab: list, optional
            A vector representing the stage-fixed x-axis in the laboratory frame for the gimbal lock scenario with z//Q.
            Defaults to [0, 0, 1] (aligned with the Z-axis).

    
    Returns:
        motorangles: list of lists
            A list of valid motor angle sets to access the Q vector with fixed psi.
    """
    # Calculate alpha based on the fixed psi value
    alpha = (psifreeze - MADparams['psi0']) * MADparams['rpsi']
    N = np.array([np.cos(np.radians(alpha)), np.sin(np.radians(alpha)), 0])  # Define normal vector in the plane

    # Extract two-theta angle, unit vector, and Qlab vector
    tth, Qlabunit, Qlab = getQlab(Q)
    # Calculate phi based on two-theta
    phi = tth * MADparams['rphi']+MADparams['phi0']

    # Compute the angle between Q and the z-axis in the lab frame
    angle_Qz = angle12(Q, [0, 0, 1])
    motorangles = []

    # Check if Q is neither perfectly along nor opposite the z-axis
    if 0.01 < angle_Qz < 179.99:
        # Define the initial z-axis in the lab frame
        zlab0 = np.array([np.cos(np.radians(angle_Qz + tth / 2 + 90)), 
                          np.sin(np.radians(angle_Qz + tth / 2 + 90)), 
                          0])
        
        # Calculate cos(theta) for the rotation angle to bring zlab0 to the plane perpendicular to N
        costheta = (
            (N[0] * zlab0[0] * Qlabunit[0] ** 2 +
             N[1] * zlab0[1] * Qlabunit[1] ** 2 +
             N[0] * zlab0[1] * Qlabunit[0] * Qlabunit[1] + 
             N[1] * zlab0[0] * Qlabunit[0] * Qlabunit[1]) /
            (-N[0] * zlab0[0] * Qlabunit[1] ** 2 -
             N[1] * zlab0[1] * Qlabunit[0] ** 2 +
             N[0] * zlab0[1] * Qlabunit[0] * Qlabunit[1] + 
             N[1] * zlab0[0] * Qlabunit[0] * Qlabunit[1])
        )

        # Check if the angle is valid
        if abs(costheta) <= 1:
            # Calculate theta values from cos(theta)
            if abs(costheta) == 1:
                theta = np.rad2deg([np.arccos(costheta)])
            else:
                theta = np.rad2deg([np.arccos(costheta), -1 * np.arccos(costheta)])
            
            # Iterate over possible theta values
            for thetai in theta:
                # Perform rotation about Qlabunit to compute new z-axis
                R_Q = Rotation.from_rotvec(thetai * Qlabunit, degrees=True)
                zlab = R_Q.apply(zlab0)

                # Compute transformation matrices for stage and lab frames from xyz to the basis consisting of z, Q and np.cross(z,Q)
                M_stage = np.linalg.inv(np.array([[0, 0, 1], Q, np.cross([0, 0, 1], Q)]).T)
                M_lab = np.array([zlab, Qlab, np.cross(zlab, Qlab)]).T

                xyzlab = np.matmul(M_lab, M_stage).T

                # Calculate motor angles
                for Set in calMAD(xyzlab, psifix=psifreeze):
                    if abs(Set[0] - psifreeze) < 0.01:  # Check psi tolerance
                        motorangles.append([phi] + Set)
        else:
            warnings.warn(f"Cannot access Q with fixed psi=`{psifreeze}`!", UserWarning)
    else:
        # Handle cases where Q is along or opposite to the z-axis
        if angle_Qz < 0.01:
            zlab = Qlabunit
        else:
            zlab = -1 * Qlabunit
        xlab = xlab
        xyzlab = np.array([xlab, np.cross(zlab, xlab), zlab])

        # Calculate motor angles
        for Set in calMAD(xyzlab, psifix=psifreeze):
            if abs(Set[0] - psifreeze) < 0.01:  # Check psi tolerance
                motorangles.append([phi] + Set)

        if len(motorangles) == 0:
            warnings.warn(f"Cannot access Q with fixed psi=`{psifreeze}`!", UserWarning)

    # Check motor limits
    if len(motorangles) > 0:
        motorangles = [Set for Set in motorangles if checkMADlimit(Set)]
        if len(motorangles) == 0:
            warnings.warn(f"Motor limits on MAD exceeded when trying to reach Q!", UserWarning)

    return motorangles

def calMADazimuthfreeze(Q, Qref, azimuthal, psifix=0):
    """
    Calculate motor angles to access a reciprocal space vector Q with a fixed azimuthal angle 
    relative to a reference vector Qref and an optional fixed psi value.

    Parameters:
        Q: numpy array
            Reciprocal space vector in the stage-fixed frame.
        Qref: numpy array
            Reference vector for defining the azimuthal angle in the staged-fixed frame.
        azimuthal: float
            Desired azimuthal angle (in degrees) of Qref, defined as the ACW rotation of the Qref around Q.
        psifix: float, optional
            Fixed psi angle (default is 0) to deal with the gimbal lock situation with z//Z.

    Returns:
        motorangles: list of lists
            A list of valid motor angle sets to access the Q vector for a fixed azimuthal angle and a reference vector Qref.

    Notes:
        Azimuthal=0 is when Qref is in the scattering plane and to the left of Qlab (same side as ki) when viewed along Z
    """

    # Extract two-theta angle, unit vector along Qlab, and Qlab vector (Q in the lab coordinate)
    tth, Qlabunit, Qlab = getQlab(Q)
    # Calculate phi based on two-theta and predefined offset (phi0)
    phi = tth * MADparams['rphi'] + MADparams['phi0']

    # Compute the angle between Q and Qref in the lab frame
    angle_Qref = angle12(Q, Qref)
    motorangles = []

    # Ensure Q and Qref are not parallel or anti-parallel
    if 0.01 < angle_Qref < 179.99:
        # Define initial Qref vector in the lab frame based on the input angle and Qref magnitude
        Qref0 = np.sqrt(np.dot(Qref, Qref)) * np.array([
            np.cos(np.radians(tth / 2 + 90 - angle_Qref)),
            np.sin(np.radians(tth / 2 + 90 - angle_Qref)),
            0
        ])

        # Apply rotation around Qlabunit
        Qreflab = Rotation.from_rotvec(azimuthal * Qlabunit,degrees=True).apply(Qref0)

        # Transformation matrices for stage and lab frames
        M_stage = np.linalg.inv(np.array([Qref, Q, np.cross(Qref, Q)]).T)  # Stage frame
        M_lab = np.array([Qreflab, Qlab, np.cross(Qreflab, Qlab)]).T        # Lab frame

        # Map stage axes to lab frame
        xyzlab = np.matmul(M_lab, M_stage).T


        # Calculate motor angles using the transformed lab axes
        for Set in calMAD(xyzlab, psifix=psifix):
            motorangles.append([phi] + Set)
    else:
        # Warn if Q and Qref are parallel or anti-parallel
        warnings.warn(f"Q and Q_ref are parallel!", UserWarning)
    
    # Check motor limits for all calculated angles
    if len(motorangles) > 0:
        motorangles = [Set for Set in motorangles if checkMADlimit(Set)]
        if len(motorangles) == 0:
            warnings.warn(f"Motor limits on MAD exceeded when trying to reach Q!", UserWarning)
    
    return motorangles

def angle_r1r2(angle1, angle2):
    """
    Calculate the angle between two reflections based on their motor angles.

    Parameters:
        angle1 (list or numpy array): Motor angles [phi, psi, chi, eta] in degrees for the first reflection.
        angle2 (list or numpy array): Motor angles [phi, psi, chi, eta] in degrees for the second reflection.

    Returns:
        float: The angle (in degrees) between the two reflections.
    """
    # Convert motor angles of the first reflection to a Q-vector in the stage-fixed coordinate system
    Q1_stage = angletoQstage(angle1)
    
    # Convert motor angles of the second reflection to a Q-vector in the stage-fixed coordinate system
    Q2_stage = angletoQstage(angle2)  
    
    # Calculate the angle between the two Q-vectors and return it
    return angle12(Q1_stage, Q2_stage)


def findallQ2(structure, Q1, angle1, Q2, step=0.5, mode=1, fixangle=0, **kwargs):
    """
    Efficiently find all possible motor angles for Q2 with a fixed angle mode and save to CSV.

    Parameters:
        structure: Object containing crystallographic structure and related methods.
        Q1: numpy array
            Reciprocal lattice vector for reflection 1 in rlu.
        angle1: numpy array or list
            Motor angles corresponding to Q1 ([phi, psi, chi, eta]).
        Q2: numpy array
            Reciprocal lattice vector for reflection 2 in rlu.
        step: float
            Azimuthal step size (in degrees).
        mode: int
            Fixed angle mode: 1 for chi-fixed, 2 for psi-fixed.
        fixangle: float
            Value of the fixed angle (chi or psi).
        **kwargs: Additional arguments for motor angle calculations.

    Returns:
        None. Saves results to a CSV file.
    """
    if mode not in [1, 2]:
        raise ValueError("Mode has to be chi-fixed (1) or psi-fixed (2)!")

    # Map modes to the appropriate calculation function
    findmotor = {
        1: calMADchifreeze,  # Chi-fixed calculation
        2: calMADpsifreeze,  # Psi-fixed calculation
    }

    # Precompute constants
    angle_12 = structure.angle(Q1, Q2)
    Q1_stage = angletoQstage(angle1)
    Q1_stagenorm = Q1_stage / np.linalg.norm(Q1_stage)

    # Generate initial Q2_stage direction either in the Q1-z or Q1-x plane
    Q2_length=np.linalg.norm(structure.rlutocartesian(Q2))
    if 0.01<angle12(Q1_stage,[0,0,1])<179.99:
        N = np.cross(Q1_stage, [0,0,1])
    else:
        N = np.cross(Q1_stage,[1,0,0])
    N /= np.linalg.norm(N)
    Q2_stage0 = Rotation.from_rotvec(angle_12 * N, degrees=True).apply(Q1_stagenorm*Q2_length)

    # Vectorized generation of all Q2_stage directions
    azimuthal_lst = np.arange(0.0, 360.0, step)
    rotations = Rotation.from_rotvec(np.outer(azimuthal_lst, Q1_stagenorm),degrees=True)  # Batch rotations
    Q2_stage_all = rotations.apply(Q2_stage0)  # Apply rotations to Q2_stage0

    # Vectorized motor angle calculation
    motor_all = []
    for Q2_stage, azimuthal in zip(Q2_stage_all, azimuthal_lst):
        motor_angles = findmotor[mode](Q2_stage, fixangle, **kwargs)
        motor_all.extend([angles + [azimuthal] for angles in motor_angles])

    # Save results to a CSV file
    df = pd.DataFrame(motor_all, columns=["phi", "psi", "chi", "eta", "azimuthal"])
    Q2_str = "_".join(map(str, Q2))  # Converts [1, 0, 0] to "1_0_0"
    df.to_csv(f"Find_{Q2_str}.csv", float_format="%.3f", index=False)
    return df



def rotate2z(v, u1, u2, step, tolerance):
    """
    Brute-force search for all combinations of angles theta1 and theta2
    that rotate the vector `v` to be parallel to (0, 0, 1) using two rotation axes `u1` and `u2`.

    Parameters:
        v (array): Normalized 3D vector to be rotated (shape: (3,)).
        u1 (array): Normalized vector giving the first rotation axis (shape: (3,)).
        u2 (array): Normalized vector giving the second rotation axis (shape: (3,)).
        step (float): Angular step (in degrees) for rotation about u1 and u2 used in the search.
        tolerance (float): Maximum deviation (in degrees) for the (theta1, theta2) pair to be accepted as a possible solution.

    Returns:
        pd.DataFrame: A DataFrame listing (theta1, theta2, deviation) that rotated `v` to align with the z-axis within tolerance.

    Notes: 
        - the deviation is almost 180 for v to be pointing along (0,0,-1)
    """
    # Define rotation angles
    theta1 = np.arange(0, 360, step)
    theta2 = np.arange(0, 360, step)

    # Create meshes for the angles
    theta1mesh, theta2mesh = np.meshgrid(theta1, theta2, indexing='ij')
    theta1_flat = theta1mesh.ravel()
    theta2_flat = theta2mesh.ravel()

    # Create rotation vectors for each axis
    R1_vectors = np.radians(theta1_flat)[:, None] * u1
    R2_vectors = np.radians(theta2_flat)[:, None] * u2

    # Create rotation matrices for each vector
    R1 = Rotation.from_rotvec(R1_vectors).as_matrix()
    R2 = Rotation.from_rotvec(R2_vectors).as_matrix()

    # Apply the rotations to the vector v
    rotated_vectors = np.einsum('ijk,ikl,l->ij', R1, R2, v)

    # Compute dot product with z-axis to check alignment
    dot_with_z = rotated_vectors[:, 2]  # z-component of rotated vectors
    cos_tolerance = np.cos(np.radians(tolerance))

    # Filter results based on tolerance
    mask = abs(dot_with_z) >= cos_tolerance
    theta1_result = theta1_flat[mask]
    theta2_result = theta2_flat[mask]
    deviation = np.degrees(np.arccos(dot_with_z[mask]))

    # Return all acceptable pairs with the deviation
    return pd.DataFrame({
        'theta1': theta1_result,
        'theta2': theta2_result,
        'deviation': deviation
    })

class rotatemount:
    """
    A class to find and refine the rotations needed to bring two reflections to the scattering (xy) plane.

    Attributes:
        Q_norm (np.ndarray): Normalized vector perpendicular to the plane of two reflections.
        N1_norm (np.ndarray): Normalized first rotation axis in the stage-fixed coordinate system.
        N2_norm (np.ndarray): Normalized second rotation axis in the stage-fixed coordinate system.
        solutions (pd.DataFrame): Initial solutions for theta1 and theta2, along with their deviations.

    Methods:
        solve(**kwargs):
            Refines the initial solutions using numerical optimization and returns refined angles.
    """
    
    def __init__(self, angle_N1, N1, angle_N2, N2, angle_1, angle_2, step=1, tolerance=1):
        """
        Initializes the rotatemount object by computing the initial solutions through brute force search.

        Parameters:
            angle_N1 (list): Motor angles [psi, chi, eta] (degrees) for the first rotation axis.
            N1 (np.ndarray): First rotation axis in the lab frame (shape: (3,)).
            angle_N2 (list): Motor angles [psi, chi, eta] (degrees) for the second rotation axis.
            N2 (np.ndarray): Second rotation axis in the lab frame (shape: (3,)).
            angle_1 (list): Motor angles [phi, psi, chi, eta] (degrees) for the first reflection.
            angle_2 (list): Motor angles [phi, psi, chi, eta] (degrees) for the second reflection.
            step (float): Angular step (in degrees) for brute-force search.
            tolerance (float): Maximum deviation (in degrees) for an acceptable solution.

        Notes:
            - the rotation around N2 precedes rotation around N1!
            - the deviation can be either close to 0, or to 180 degrees
                corresponding to a positive (ACW) and negative (CW) rotation from Q1 to Q2 with respect to the z-axis
        """
        # Convert reflections into stage-fixed coordinates
        Q1 = angletoQstage(angle_1)
        Q2 = angletoQstage(angle_2)

        # Validate the input: Ensure reflections are not parallel
        angle_12 = angle12(Q1, Q2)
        if angle_12 < 0.01:
            raise ValueError("The two reflections are parallel!")

        # Compute the normal vector to the two reflections Q1 and Q2
        self.Q_norm = np.cross(Q1, Q2) / np.linalg.norm(np.cross(Q1, Q2))

        # Transform rotation axes into stage-fixed coordinates and normalize
        self.N1_norm = (
            Rmad(angle_N1[0], angle_N1[1], angle_N1[2])
            .inv()
            .apply(N1)
            / np.linalg.norm(N1)
        )
        self.N2_norm = (
            Rmad(angle_N2[0], angle_N2[1], angle_N2[2])
            .inv()
            .apply(N2)
            / np.linalg.norm(N2)
        )

        # Compute initial solutions using brute-force search
        self.solutions = rotate2z(self.Q_norm, self.N1_norm, self.N2_norm, step, tolerance)
        print(f"Found {len(self.solutions)} initial solutions.")

    def solve(self, **kwargs):
        """
        Refines the initial solutions using numerical optimization (scipy.optimize.root).

        Parameters:
            **kwargs: Additional arguments to pass to `scipy.optimize.root`.

        Returns:
            pd.DataFrame: A DataFrame containing refined theta1, theta2 angles and their deviations.
        """

        def rotate12(angles):
            """
            Applies two rotations (angles[0] about N1_norm, angles[1] about N2_norm) to Q_norm.

            Parameters:
                angles (list): List of two angles [theta1, theta2] in degrees.

            Returns:
                tuple: Rotated vector and its deviation from the z-axis.
            """
            R1 = Rotation.from_rotvec(angles[0] * self.N1_norm, degrees=True).as_matrix()
            R2 = Rotation.from_rotvec(angles[1] * self.N2_norm, degrees=True).as_matrix()
            vfinal = np.einsum('ij,jk,k->i', R1, R2, self.Q_norm)
            return vfinal, np.rad2deg(np.arccos(vfinal[2]))

        def func(angles):
            """
            Objective function for numerical optimization.

            Parameters:
                angles (list): List of two angles [theta1, theta2].

            Returns:
                np.ndarray: The x and y components of the rotated vector.
            """
            vfinal, _ = rotate12(angles)
            return vfinal[:-1]  # Return only x and y components

        # Refine solutions
        solutions_better = []
        for angle_pair in self.solutions.iloc[:, :2].itertuples(index=False, name=None):
            refined = optimize.root(func, x0=angle_pair, **kwargs).x
            solutions_better.append(np.round(refined, 2))

        # Remove duplicates and calculate deviations
        solutions_better = np.unique(np.array(solutions_better), axis=0)
        theta1_result = solutions_better[:, 0]
        theta2_result = solutions_better[:, 1]
        deviation = [rotate12(angle_pair)[1] for angle_pair in solutions_better]

        return pd.DataFrame({
            'theta1': theta1_result,
            'theta2': theta2_result,
            'deviation': deviation
        })





class UB:
    """
    A class to construct the UB matrix for a crystal structure based on experimentally observed 
    and theoretical values of reciprocal lattice vectors and angles.

    Attributes:
        M_rs: numpy array
            Matrix for conversion from reciprocal lattice units (rlu) to the stage-fixed coordinate system.
        M_sr: numpy array
            Matrix for conversion from the stage-fixed coordinate system to reciprocal lattice units (rlu).
        Q1: numpy array
            The Q1 vector used to construct the UB matrix, in reciprocal lattice units (rlu).
        Q2: numpy array
            The Q2 vector used to construct the UB matrix, in reciprocal lattice units (rlu).
        angle1: list
            Motor angles (phi, psi, chi, eta) corresponding to Q1.
        angle2: list
            Motor angles (phi, psi, chi, eta) corresponding to Q2.
    
    Notes:
        - The most important outputs are the conversion matrices, M_rs and M_sr
        - M_rs is by definition the UB matrix. However, the 'intermediate' coordinate systems attached to the crystal was taken to be a non-orthogonal basis in my code
        - The UB matrix produced is a 'best-fit' that 
            - scales Q1 and Q2 to the experimentally observed lengths
            - rotate Q2 so that the angles between Q1 and Q2 match that observed experimentally 
    """
    def __init__(self, structure, Q1, angle1, Q2, angle2):
        """
        Initialize the UB matrix based on the crystal structure and experimental values.

        Parameters:
            structure: object
                The crystal structure object with methods for crystallographic calculations.
            Q1: numpy array
                First reciprocal lattice vector in rlu.
            angle1: list
                Motor angles (phi, psi, chi, eta) corresponding to Q1.
            Q2: numpy array
                Second reciprocal lattice vector in rlu.
            angle2: list
                Motor angles (phi, psi, chi, eta) corresponding to Q2.
        """
        self.angle1 = angle1
        self.angle2 = angle2

        # Convert experimental motor angles to stage-fixed reciprocal space vectors
        Q1_stage = angletoQstage(self.angle1)
        Q2_stage = angletoQstage(self.angle2)

        # Compute a third orthogonal vector using the cross product
        Q3_stage = np.cross(Q1_stage, Q2_stage)

        # Calculate the experimental angle between Q1_stage and Q2_stage
        angle12_exp = angle12(Q1_stage, Q2_stage)
        
        # Calculate theoretical angle between Q1 and Q2 in the crystal frame
        angle12_the = structure.angle(Q1, Q2)


        # Raise an error if either Q1_stage//Q2_stage or Q1//Q2
        if angle12_exp>179.99 or angle12_exp<0.01:
            raise ValueError("The two reflections found are parallel!")
        
        elif angle12_the>179.99 or angle12_the<0.01:
            raise ValueError(f"The two reflections, `{Q1}` and `{Q2}`,  are parallel!")

        # Function to scale Q vectors to match experimental lengths
        def scaleQ(Q, Q_stage, tth_exp):
            Q_crystal = structure.rlutocartesian(Q)  # Convert Q from rlu to cartesian
            tth_the = structure.twotheta(Q, ki)  # Calculate theoretical two-theta

            # Scale the Q vector to match the observed experimental length
            Q_crystalnew = Q_crystal / np.sqrt(np.dot(Q_crystal, Q_crystal)) * np.sqrt(np.dot(Q_stage, Q_stage))

            # Warn if the observed and theoretical two-theta differ significantly
            if abs(tth_the - tth_exp) > 5:
                warnings.warn(
                    f"Observed and calculated two-theta for `{Q}` differ by more than 5 degrees!",
                    UserWarning
                )
            return Q_crystalnew

        # Scale Q1 and Q2 vectors based on experimental data
        Q1_crystal = scaleQ(Q1, Q1_stage, (self.angle1[0] - MADparams['phi0']) * MADparams['rphi'])
        Q2_crystal = scaleQ(Q2, Q2_stage, (self.angle2[0] - MADparams['phi0']) * MADparams['rphi'])

        # Adjust Q2_crystal to match the experimentally observed angle with Q1_crystal
        N = np.cross(Q1_crystal, Q2_crystal)  # Calculate normal vector to Q1 and Q2
        N = N / np.sqrt(np.dot(N, N))  # Normalize the normal vector
        Q2_crystal = Rotation.from_rotvec(angle12_exp * N, degrees=True).apply(Q1_crystal/np.linalg.norm(Q1_crystal)*np.linalg.norm(Q2_crystal))

        # Warn if the experimental and theoretical angles differ significantly
        if abs(angle12_exp - angle12_the) > 5:
            warnings.warn(
                f"Observed and calculated angle between `{Q1}` and `{Q2}` differ by more than 5 degrees!",
                UserWarning
            )

        # Compute the third orthogonal vector in the crystal frame
        Q3_crystal = np.cross(Q1_crystal, Q2_crystal)

        # Define transformation matrices for the crystal and stage-fixed frames
        M1 = np.array([structure.B1c, structure.B2c, structure.B3c]).T  # Basis vectors in crystal frame
        M2 = np.array([Q1_crystal, Q2_crystal, Q3_crystal]).T  # Basis vectors from scaled Q vectors
        M3 = np.array([Q1_stage, Q2_stage, Q3_stage]).T  # Basis vectors in stage-fixed frame

        # Compute transformation matrices
        M_rluto123 = np.matmul(np.linalg.inv(M2), M1)  # rlu to scaled crystal frame
        self.M_rs = np.matmul(M3, M_rluto123)  # rlu to stage-fixed frame
        self.M_sr = np.linalg.inv(self.M_rs)  # Stage-fixed frame to rlu

        # Save the Q1 and Q2 vectors used to construct the UB matrix
        self.Q1 = np.matmul(np.linalg.inv(M1), Q1_crystal)
        self.Q2 = np.matmul(np.linalg.inv(M1), Q2_crystal)

        # Print summary of the UB matrix construction
        print("\n" + "=" * 60)
        print(" UB Matrix Construction Summary ")
        print("=" * 60)
        print("Motor Angles (phi, psi, chi, eta) for Q1:")
        print(f"  {self.angle1}")
        print("\nQ1 Vector (in reciprocal lattice units):")
        print(f"  {self.Q1}")
        print("-" * 60)
        print("Motor Angles (phi, psi, chi, eta) for Q2:")
        print(f"  {self.angle2}")
        print("\nQ2 Vector (in reciprocal lattice units):")
        print(f"  {self.Q2}")
        print("=" * 60)

    def rlutostage(self, Q):
        """
        Convert a list of vectors from reciprocal lattice units (rlu) to the stage-fixed coordinate system.

        Parameters:
            Q: numpy array or list
                A list of vectors in rlu, provided as an (N, 3) numpy array or list of N vectors.

        Returns:
            numpy array:
                The same vectors transformed into the stage-fixed coordinate system.
        """
        return np.matmul(self.M_rs, np.array(Q).T).T

        
    def stagetorlu(self,Q):
        """
        Convert a list of vectors from stage-fixed coordinate system to rlu. 
        """
        return np.matmul(self.M_sr,np.array(Q).T).T
    
    def findQ(self, angles):
        """
        Calculate the Q-vector (in reciprocal lattice units) corresponding to a set of motor angles.

        Parameters:
            angles (list or numpy array): A list of motor angles (e.g., [phi, psi, chi, eta]) in degrees.

        Returns:
            numpy array: The Q-vector in reciprocal lattice units (rlu).
        """
        Qstage = angletoQstage(angles)  # Convert motor angles to a Q-vector in the stage-fixed coordinate system.
        return self.stagetorlu(Qstage)  # Transform the stage-fixed Q-vector to reciprocal lattice units.

    def toQ(self, mode, Q, *args, **kwargs):
        """
        Determine the motor angles required to access a specific Q-vector, 
        based on a selected fixed-angle mode.

        Parameters:
            mode (int): The mode for calculating the motor angles. Must be one of:
                - 1: Chi-fixed
                - 2: Psi-fixed
                - 3: Azimuthal angle-fixed
            Q (list or array): The vector to be accessed given by a (3, ) list or array 
            *args: Positional arguments to pass to the corresponding calculation function.
                *args=chifreeze and psifreeze for mode 1 and 2
                *args=Qref, psifreeze for mode 3
            **kwargs: Keyword arguments to pass to the corresponding calculation function.

        Returns:
            list: Motor angles that satisfy the given Q-vector and mode constraints.

        Raises:
            ValueError: If the mode is not one of the valid options (1, 2, or 3).
        """
        # Ensure the mode is valid
        if mode not in [1, 2, 3]:
            raise ValueError(
                "Mode has to be chi-fixed (1), psi-fixed (2), or azimuthal angle-fixed (3)!"
            )

        # Map modes to the appropriate calculation function
        findmotor = {
            1: calMADchifreeze,       # Chi-fixed calculation
            2: calMADpsifreeze,       # Psi-fixed calculation
            3: calMADazimuthfreeze    # Azimuthal angle-fixed calculation
        }

        # Convert Q to stage-fixed coordinate
        Q_stage=self.rlutostage(Q)

        # Call the appropriate function with the provided arguments and return the result
        motorangles = findmotor[mode](Q_stage, *args, **kwargs)
        return motorangles

    






            
            


        


