import os
import importlib

def import_all_modules():
    """
    Dynamically imports all Python files in the current directory
    and makes their contents available directly or under a common namespace.
    """
    current_folder = os.path.dirname(__file__)  # Get the directory of the master file
    py_files = [f for f in os.listdir(current_folder) if f.endswith('.py') and f != 'MAD800.py']

    for py_file in py_files:
        module_name = os.path.splitext(py_file)[0]  # Get the file name without the extension
        module = importlib.import_module(module_name)  # Import the module

        # Expose all module attributes (except private ones) to the global namespace
        for attr_name in dir(module):
            if not attr_name.startswith('_'):  # Skip private attributes
                globals()[attr_name] = getattr(module, attr_name)

        # Optionally, make modules accessible as `master.module_name`
        globals()[f"MAD800.{module_name}"] = module


# Import all modules when this master file is imported
import_all_modules()
